package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AutoCrystal extends Module {

    private final Setting<Double>  placeRange  = register(new Setting<>("PlaceRange",  4.0, 1.0, 6.0));
    private final Setting<Double>  breakRange  = register(new Setting<>("BreakRange",  5.0, 1.0, 6.0));
    private final Setting<Double>  minDamage   = register(new Setting<>("MinDamage",   6.0, 1.0, 36.0));
    private final Setting<Double>  maxSelf     = register(new Setting<>("MaxSelfDmg",  8.0, 0.0, 36.0));
    private final Setting<Integer> delay       = register(new Setting<>("Delay",       2, 0, 20));
    private final Setting<Boolean> antiSuicide = register(new Setting<>("AntiSuicide", true));

    private int tickCount = 0;

    public AutoCrystal() {
        super("AutoCrystal", "Automatically places and detonates end crystals", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (tickCount++ < delay.getValue()) return;
        tickCount = 0;

        // 1. Break existing crystals near target
        breakCrystals(mc);

        // 2. Place new crystal on best position
        placeCrystal(mc);
    }

    private void breakCrystals(MinecraftClient mc) {
        PlayerEntity target = findTarget(mc);
        if (target == null) return;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity crystal)) continue;
            if (mc.player.distanceTo(crystal) > breakRange.getValue()) continue;

            double dmg = calcExplosionDamage(target, crystal.getPos(), 6f);
            if (dmg < minDamage.getValue()) continue;

            // check self damage
            double selfDmg = calcExplosionDamage(mc.player, crystal.getPos(), 6f);
            if (antiSuicide.getValue() && selfDmg >= mc.player.getHealth()) continue;
            if (selfDmg > maxSelf.getValue()) continue;

            mc.interactionManager.attackEntity(mc.player, crystal);
            mc.player.swingHand(Hand.MAIN_HAND);
            break;
        }
    }

    private void placeCrystal(MinecraftClient mc) {
        if (!hasCrystal(mc.player)) return;

        PlayerEntity target = findTarget(mc);
        if (target == null) return;

        BlockPos bestPos  = null;
        double   bestDmg  = minDamage.getValue();

        // check blocks in a cube around target
        BlockPos tPos = target.getBlockPos();
        for (int x = -3; x <= 3; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -3; z <= 3; z++) {
                    BlockPos pos = tPos.add(x, y, z);
                    if (!isValidPlacement(mc, pos)) continue;
                    if (mc.player.distanceTo(Vec3d.ofCenter(pos)) > placeRange.getValue()) continue;

                    Vec3d crystalCenter = Vec3d.of(pos).add(0.5, 1.0, 0.5);
                    double dmg     = calcExplosionDamage(target, crystalCenter, 6f);
                    double selfDmg = calcExplosionDamage(mc.player, crystalCenter, 6f);

                    if (antiSuicide.getValue() && selfDmg >= mc.player.getHealth()) continue;
                    if (selfDmg > maxSelf.getValue()) continue;

                    if (dmg > bestDmg) {
                        bestDmg = dmg;
                        bestPos = pos;
                    }
                }
            }
        }

        if (bestPos == null) return;

        // switch to crystal slot, place, switch back
        int prevSlot = mc.player.getInventory().selectedSlot;
        int crystalSlot = findCrystalSlot(mc.player);
        if (crystalSlot == -1) return;

        mc.player.getInventory().selectedSlot = crystalSlot;
        Vec3d hitVec = Vec3d.of(bestPos).add(0.5, 0.5, 0.5);
        mc.interactionManager.interactBlock(
            mc.player, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, net.minecraft.util.math.Direction.UP, bestPos, false)
        );
        mc.player.getInventory().selectedSlot = prevSlot;
    }

    // Simplified explosion damage calc (real impl needs block resistance map)
    private double calcExplosionDamage(Entity entity, Vec3d explosionPos, float power) {
        double dist   = entity.getPos().distanceTo(explosionPos);
        double radius = power * 2.0;
        if (dist > radius) return 0;

        double exposure = 1.0 - (dist / radius);
        double impact   = (exposure * exposure + exposure) / 2.0;
        double baseDmg  = (impact * impact + impact) / 2.0 * 7.0 * power + 1.0;

        // armor / blast protection would reduce this — skipping for brevity
        return baseDmg;
    }

    private boolean isValidPlacement(MinecraftClient mc, BlockPos pos) {
        var base = mc.world.getBlockState(pos);
        var above = mc.world.getBlockState(pos.up());
        var above2 = mc.world.getBlockState(pos.up(2));

        // crystal can only be placed on obsidian or bedrock
        if (!base.isOf(net.minecraft.block.Blocks.OBSIDIAN) &&
            !base.isOf(net.minecraft.block.Blocks.BEDROCK)) return false;

        return above.isAir() && above2.isAir();
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        PlayerEntity best = null;
        float bestHealth = Float.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (p.isDead() || p.getHealth() <= 0) continue;
            if (mc.player.distanceTo(p) > placeRange.getValue() + 3) continue;
            if (p.getHealth() < bestHealth) {
                bestHealth = p.getHealth();
                best = p;
            }
        }
        return best;
    }

    private boolean hasCrystal(ClientPlayerEntity player) {
        return findCrystalSlot(player) != -1;
    }

    private int findCrystalSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).getItem() == Items.END_CRYSTAL) return i;
        }
        return -1;
    }
}
