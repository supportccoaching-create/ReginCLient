package com.regin.client.module.combat;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

public class HitBox extends Module {
    public final Setting<Double> expand = register(new Setting<>("Expand", 0.1, 0.0, 0.5));

    public HitBox() {
        super("HitBox", "Expands entity hitboxes client-side for easier hitting", Category.COMBAT);
    }
    // Applied via mixin: Entity#getBoundingBox().expand(expand.getValue())
}
