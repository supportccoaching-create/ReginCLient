package com.regin.client.module.render;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Fullbright extends Module {
    private final Setting<Double> gamma = register(new Setting<>("Gamma", 100.0, 1.0, 100.0));

    public Fullbright() { super("Fullbright", "Maximum brightness regardless of light level", Category.RENDER); }

    @Override public void onEnable()  {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.gamma.setValue(gamma.getValue());
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.gamma.setValue(1.0);
    }
}
