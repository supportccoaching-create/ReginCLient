package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

public class SpearSwap extends Module {
    private final Setting<Double> rangeThreshold = register(new Setting<>("RangeThreshold", 8.0, 2.0, 20.0));

    public SpearSwap() {
        super("SpearSwap", "Auto-equips trident for ranged attacks, swaps back when close", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        double nearestDist = Double.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead()) continue;
            double d = mc.player.distanceTo(p);
            if (d < nearestDist) nearestDist = d;
        }

        if (nearestDist > rangeThreshold.getValue()) {
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getStack(i).getItem() == Items.TRIDENT) {
                    mc.player.getInventory().selectedSlot = i;
                    return;
                }
            }
        }
    }
}
