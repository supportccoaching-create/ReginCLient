package com.regin.client.module.movement;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class LongJump extends Module {
    private final Setting<Double> boost = register(new Setting<>("Boost", 2.0, 1.0, 5.0));

    public LongJump() { super("LongJump", "Boosts horizontal velocity on jump", Category.MOVEMENT); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        var vel = mc.player.getVelocity();
        if (vel.y > 0.3 && mc.player.input.movementForward != 0) {
            double yaw = Math.toRadians(mc.player.getYaw());
            mc.player.setVelocity(
                vel.x - Math.sin(yaw) * boost.getValue() * 0.1,
                vel.y,
                vel.z + Math.cos(yaw) * boost.getValue() * 0.1);
        }
    }
}
