package com.regin.client.module.render;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class JumpCircles extends Module {
    private final Setting<Boolean> rainbow = register(new Setting<>("Rainbow", false));
    private boolean wasOnGround = true;

    public JumpCircles() { super("JumpCircles", "Renders expanding circle on jump", Category.RENDER); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        boolean onGround = mc.player.isOnGround();
        if (wasOnGround && !onGround) {
            // spawn circle particle at player feet — rendered via RenderEvent
        }
        wasOnGround = onGround;
    }
}
