package com.regin.client.module.movement;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class SafeWalk extends Module {
    public SafeWalk() { super("SafeWalk", "Prevents walking off edges", Category.MOVEMENT); }
    // Mixin: forces isSneaking()=true for movement edge detection
}
