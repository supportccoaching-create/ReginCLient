package com.regin.client.module;

import com.regin.client.core.Client;
import com.regin.client.setting.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    private final String   name;
    private final String   description;
    private final Category category;
    private       boolean  enabled;
    private       int      key;

    protected final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
        this.enabled     = false;
        this.key         = GLFW.GLFW_KEY_UNKNOWN;
    }

    // ── lifecycle ─────────────────────────────────────────────────────────────

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}

    // ── toggle ────────────────────────────────────────────────────────────────

    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            Client.INSTANCE.eventBus.subscribe(this);
            onEnable();
        } else {
            onDisable();
            Client.INSTANCE.eventBus.unsubscribe(this);
        }
    }

    public void setEnabled(boolean state) {
        if (state != enabled) toggle();
    }

    // ── settings helper ───────────────────────────────────────────────────────

    protected <T> Setting<T> register(Setting<T> s) {
        settings.add(s);
        return s;
    }

    // ── getters ───────────────────────────────────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isEnabled()      { return enabled; }
    public int      getKey()         { return key; }
    public void     setKey(int key)  { this.key = key; }
    public List<Setting<?>> getSettings() { return settings; }
}
