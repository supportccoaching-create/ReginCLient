package com.regin.client.module.player;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class NoFall extends Module {
    public NoFall() { super("NoFall", "Cancels fall damage", Category.PLAYER); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (mc.player.fallDistance > 3f) mc.player.fallDistance = 0f;
    }
}
