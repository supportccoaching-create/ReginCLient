package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class AutoLog extends Module {
    private final Setting<Double> hp = register(new Setting<>("HP", 6.0, 1.0, 20.0));

    public AutoLog() { super("AutoLog", "Disconnects when HP drops below threshold", Category.MISC); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (mc.player.getHealth() <= hp.getValue())
            mc.getNetworkHandler().getConnection().disconnect(
                net.minecraft.text.Text.literal("AutoLog"));
    }
}
