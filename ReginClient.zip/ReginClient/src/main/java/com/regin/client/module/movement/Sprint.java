package com.regin.client.module.movement;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Sprint extends Module {
    private final Setting<Boolean> omni = register(new Setting<>("Omni", false));

    public Sprint() { super("Sprint", "Auto-sprints in movement direction", Category.MOVEMENT); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        boolean moving = mc.player.input.movementForward != 0
                      || (omni.getValue() && mc.player.input.movementSideways != 0);
        if (moving && !mc.player.isSprinting() && !mc.player.isUsingItem()
                && mc.player.getHungerManager().getFoodLevel() > 6)
            mc.player.setSprinting(true);
    }
}
