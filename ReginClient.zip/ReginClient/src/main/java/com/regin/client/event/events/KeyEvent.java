package com.regin.client.event.events;

import com.regin.client.event.Event;

public class KeyEvent extends Event {
    public final int key;
    public final int action;

    public KeyEvent(int key, int action) {
        this.key    = key;
        this.action = action;
    }
}
