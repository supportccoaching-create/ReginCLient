package com.regin.client.mixin;

import com.regin.client.core.Client;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (Client.INSTANCE.keybindManager == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen != null
                && !(mc.currentScreen instanceof com.regin.client.gui.ClickGUI)) return;
        Client.INSTANCE.keybindManager.onKey(key, action);
    }
}
