package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;

public class AutoHitCrystal extends Module {
    private final Setting<Double> range = register(new Setting<>("Range", 5.0, 1.0, 8.0));

    public AutoHitCrystal() {
        super("AutoHitCrystal", "Auto-attacks end crystals within range", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (var entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity)) continue;
            if (mc.player.distanceTo(entity) > range.getValue()) continue;
            mc.interactionManager.attackEntity(mc.player, entity);
            mc.player.swingHand(Hand.MAIN_HAND);
            break;
        }
    }
}
