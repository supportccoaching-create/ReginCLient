package com.regin.client.module;

public enum Category {
    COMBAT      ("Combat"),
    MOVEMENT    ("Movement"),
    RENDER      ("Render"),
    MISC        ("Misc"),
    PLAYER      ("Player"),
    EXPLOIT     ("Exploit"),
    DONUT       ("Donut"),
    BASEFINDING ("Base Finding");

    public final String displayName;
    Category(String displayName) { this.displayName = displayName; }
}
