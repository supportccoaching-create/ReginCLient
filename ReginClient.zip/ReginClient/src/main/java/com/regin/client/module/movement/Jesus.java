package com.regin.client.module.movement;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class Jesus extends Module {
    public Jesus() { super("Jesus", "Walk on water and lava", Category.MOVEMENT); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (mc.player.isTouchingWater() || mc.player.isInLava()) {
            var vel = mc.player.getVelocity();
            if (vel.y < 0) mc.player.setVelocity(vel.x, 0.04, vel.z);
        }
    }
}
