package com.regin.client.mixin;

import com.regin.client.core.Client;
import com.regin.client.event.events.TickEvent;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTickPre(CallbackInfo ci) {
        if (Client.INSTANCE.eventBus == null) return;
        Client.INSTANCE.eventBus.post(new TickEvent(TickEvent.Phase.PRE));
        Client.INSTANCE.keybindManager.update();
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTickPost(CallbackInfo ci) {
        if (Client.INSTANCE.eventBus == null) return;
        Client.INSTANCE.eventBus.post(new TickEvent(TickEvent.Phase.POST));
    }
}
