package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;

public class DoubleAnchor extends Module {
    public DoubleAnchor() {
        super("DoubleAnchor", "Places two respawn anchors simultaneously for double explosion", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        boolean hasAnchor = false;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.RESPAWN_ANCHOR) {
                mc.player.getInventory().selectedSlot = i;
                hasAnchor = true;
                break;
            }
        }
        if (!hasAnchor) return;

        BlockPos feet   = mc.player.getBlockPos();
        BlockPos offset = feet.east();

        for (BlockPos pos : new BlockPos[]{ feet, offset }) {
            if (!mc.world.getBlockState(pos).isAir()) continue;
            Vec3d hitVec = Vec3d.of(pos).add(0.5, 0.5, 0.5);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(hitVec, Direction.UP, pos, false));
        }
    }
}
