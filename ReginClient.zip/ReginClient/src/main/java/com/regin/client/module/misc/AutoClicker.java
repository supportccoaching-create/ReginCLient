package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;

import java.util.Random;

public class AutoClicker extends Module {

    private final Setting<Double>  minCps   = register(new Setting<>("MinCPS",   8.0,  1.0, 20.0));
    private final Setting<Double>  maxCps   = register(new Setting<>("MaxCPS",  12.0,  1.0, 20.0));
    private final Setting<Boolean> leftBtn  = register(new Setting<>("Left",     true));
    private final Setting<Boolean> rightBtn = register(new Setting<>("Right",    false));

    private final Random rng       = new Random();
    private       long   nextClick = 0;

    public AutoClicker() {
        super("AutoClicker", "Humanized auto-clicker with Gaussian CPS jitter", Category.MISC);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long now = System.currentTimeMillis();
        if (now < nextClick) return;

        // Gaussian CPS — mean between min/max, sigma = range/6
        double mean     = (minCps.getValue() + maxCps.getValue()) / 2.0;
        double sigma    = (maxCps.getValue() - minCps.getValue()) / 6.0;
        double cps      = Math.max(minCps.getValue(),
                            Math.min(maxCps.getValue(), mean + rng.nextGaussian() * sigma));
        long   interval = (long)(1000.0 / cps);

        // add small jitter ±5% to interval itself
        nextClick = now + interval + (long)(rng.nextGaussian() * interval * 0.05);

        if (leftBtn.getValue() && mc.options.attackKey.isPressed()) {
            if (mc.targetedEntity != null)
                mc.interactionManager.attackEntity(mc.player, mc.targetedEntity);
            mc.player.swingHand(Hand.MAIN_HAND);
        }

        if (rightBtn.getValue() && mc.options.useKey.isPressed())
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
    }
}
