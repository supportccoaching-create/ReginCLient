package com.regin.client.module.player;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", "Automatically respawns on death", Category.PLAYER); }
    // Mixin on DeathScreen#init: immediately sends ClientStatusC2SPacket(PERFORM_RESPAWN)
}
