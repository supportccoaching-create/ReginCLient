package com.regin.client.input;

import com.regin.client.core.Client;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {

    private boolean[] keyStates    = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private boolean[] prevStates   = new boolean[GLFW.GLFW_KEY_LAST + 1];

    // Called from mixin on KeyboardMixin#onKey
    public void onKey(int key, int action) {
        if (key < 0 || key > GLFW.GLFW_KEY_LAST) return;

        prevStates[key] = keyStates[key];
        keyStates[key]  = (action != GLFW.GLFW_RELEASE);

        // only fire on key press (not hold)
        if (action == GLFW.GLFW_PRESS) {
            Client.INSTANCE.moduleManager.onKeyPress(key);

            // GUI toggle
            if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.currentScreen instanceof com.regin.client.gui.ClickGUI) {
                    mc.setScreen(null);
                } else {
                    mc.setScreen(Client.INSTANCE.clickGUI);
                }
            }
        }
    }

    public boolean isKeyDown(int key) {
        if (key < 0 || key > GLFW.GLFW_KEY_LAST) return false;
        return keyStates[key];
    }

    public boolean isKeyPressed(int key) {
        if (key < 0 || key > GLFW.GLFW_KEY_LAST) return false;
        return keyStates[key] && !prevStates[key];
    }

    public void update() {
        System.arraycopy(keyStates, 0, prevStates, 0, keyStates.length);
    }
}
