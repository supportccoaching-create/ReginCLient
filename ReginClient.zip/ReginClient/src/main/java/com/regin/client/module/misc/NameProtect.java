package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

public class NameProtect extends Module {
    public final Setting<String> replacement = register(new Setting<>("Name", "Player"));

    public NameProtect() { super("NameProtect", "Replaces your username in client-side rendering", Category.MISC); }
    // Mixin on GameProfile#getName: if profile == local player, return replacement.getValue()
}
