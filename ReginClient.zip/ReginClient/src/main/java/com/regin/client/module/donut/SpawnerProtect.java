package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class SpawnerProtect extends Module {
    private final java.util.List<BlockPos> tracked = new java.util.ArrayList<>();

    public SpawnerProtect() {
        super("SpawnerProtect", "Alerts when a player approaches a tracked spawner", Category.DONUT);
    }

    public void trackCrosshair() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.crosshairTarget instanceof net.minecraft.util.hit.BlockHitResult bhr)
            tracked.add(bhr.getBlockPos());
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        for (var player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            for (BlockPos sp : tracked) {
                double dist = player.getPos()
                    .distanceTo(net.minecraft.util.math.Vec3d.of(sp));
                if (dist < 32) {
                    mc.player.sendMessage(
                        net.minecraft.text.Text.literal(
                            "§5[SpawnerProtect] §d"
                            + player.getName().getString()
                            + " near spawner @ " + sp.toShortString()), false);
                }
            }
        }
    }
}

// ── ChunkFinder ───────────────────────────────────────────────────────────────
