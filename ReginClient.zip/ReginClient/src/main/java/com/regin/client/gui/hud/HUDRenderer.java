package com.regin.client.gui.hud;

import com.regin.client.core.Client;
import com.regin.client.module.Module;
import com.regin.client.module.render.HUD;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.Comparator;
import java.util.List;

public class HUDRenderer {

    // ── Palette ───────────────────────────────────────────────────────────────
    private static final int COLOR_PRIMARY   = 0xFFA020F0;
    private static final int COLOR_SECONDARY = 0xFFE0B0FF;
    private static final int COLOR_TEXT      = 0xFFE0B0FF;
    private static final int COLOR_DIM       = 0xFF9060B0;
    private static final int COLOR_BG        = 0xAA100010;
    private static final int COLOR_ENABLED   = 0xFFA020F0;

    public void render(DrawContext ctx, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!Client.INSTANCE.moduleManager.get(HUD.class).isEnabled()) return;

        TextRenderer font = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        renderWatermark(ctx, font);
        renderModuleList(ctx, font, sw);
        renderCoords(ctx, font, mc, sh);
        renderFPS(ctx, font, mc, sw, sh);
        renderTargetHUD(ctx, font, mc, sw, sh);
    }

    // ── Watermark ─────────────────────────────────────────────────────────────
    private void renderWatermark(DrawContext ctx, TextRenderer font) {
        String text = "§5Regin§dClient";
        ctx.fill(2, 2, 4 + font.getWidth("ReginClient"), 12, COLOR_BG);
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal(text), 3, 3, COLOR_PRIMARY);
    }

    // ── Module list (right side, sorted by name length) ───────────────────────
    private void renderModuleList(DrawContext ctx, TextRenderer font, int sw) {
        List<Module> enabled = Client.INSTANCE.moduleManager.getEnabled()
            .stream()
            .sorted(Comparator.comparingInt(m -> -font.getWidth(m.getName())))
            .toList();

        int y = 2;
        for (Module m : enabled) {
            String name  = m.getName();
            int    width = font.getWidth(name);
            int    x     = sw - width - 4;

            // background pill
            ctx.fill(x - 2, y, sw, y + 10, COLOR_BG);
            // left accent bar
            ctx.fill(x - 2, y, x - 1, y + 10, COLOR_PRIMARY);
            // text
            ctx.drawTextWithShadow(font,
                net.minecraft.text.Text.literal(name), x, y + 1, COLOR_SECONDARY);
            y += 11;
        }
    }

    // ── Coordinates ───────────────────────────────────────────────────────────
    private void renderCoords(DrawContext ctx, TextRenderer font, MinecraftClient mc, int sh) {
        BlockPos pos = mc.player.getBlockPos();
        String text  = String.format("§5X:§d%d §5Y:§d%d §5Z:§d%d",
            pos.getX(), pos.getY(), pos.getZ());
        ctx.fill(2, sh - 22, 4 + font.getWidth("X:00000 Y:000 Z:00000"), sh - 12, COLOR_BG);
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal(text), 3, sh - 21, COLOR_TEXT);

        // nether coords
        if (mc.world != null && mc.world.getRegistryKey()
                == net.minecraft.registry.RegistryKey.of(
                    net.minecraft.registry.RegistryKeys.WORLD,
                    net.minecraft.util.Identifier.of("minecraft", "overworld"))) {
            String nether = String.format("§5N: §d%d §5/ §d%d",
                pos.getX() / 8, pos.getZ() / 8);
            ctx.drawTextWithShadow(font,
                net.minecraft.text.Text.literal(nether), 3, sh - 11, COLOR_DIM);
        }
    }

    // ── FPS ───────────────────────────────────────────────────────────────────
    private void renderFPS(DrawContext ctx, TextRenderer font,
                           MinecraftClient mc, int sw, int sh) {
        String fps = "§5FPS: §d" + mc.getCurrentFps();
        int    x   = sw - font.getWidth("FPS: 000") - 4;
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal(fps), x, sh - 11, COLOR_DIM);
    }

    // ── Target HUD ────────────────────────────────────────────────────────────
    private void renderTargetHUD(DrawContext ctx, TextRenderer font,
                                 MinecraftClient mc, int sw, int sh) {
        Entity target = mc.targetedEntity;
        if (!(target instanceof LivingEntity le)) return;

        int   panelW = 120;
        int   panelH = 30;
        int   px     = sw / 2 - panelW / 2;
        int   py     = sh - 80;

        // panel background
        ctx.fill(px, py, px + panelW, py + panelH, COLOR_BG);
        // top accent line
        ctx.fill(px, py, px + panelW, py + 1, COLOR_PRIMARY);

        // name
        String name = le.getName().getString();
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal("§d" + name), px + 4, py + 3, COLOR_TEXT);

        // HP bar
        float hp    = le.getHealth();
        float maxHp = le.getMaxHealth();
        float ratio = hp / maxHp;

        int barW   = panelW - 8;
        int barX   = px + 4;
        int barY   = py + 14;

        ctx.fill(barX, barY, barX + barW, barY + 6, 0xFF1A001A);

        int    filled = (int)(barW * ratio);
        int    r      = (int)((1 - ratio) * 255);
        int    g      = (int)(ratio * 180);
        int    hpCol  = 0xFF000000 | (r << 16) | (g << 8);
        ctx.fill(barX, barY, barX + filled, barY + 6, hpCol);

        // HP text
        String hpStr = String.format("§7%.1f / %.1f", hp, maxHp);
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal(hpStr),
            barX, barY + 9, COLOR_DIM);

        // distance
        double dist = mc.player.distanceTo(target);
        String distStr = String.format("§5%.1fm", dist);
        ctx.drawTextWithShadow(font,
            net.minecraft.text.Text.literal(distStr),
            px + panelW - font.getWidth(distStr.replaceAll("§.", "")) - 4,
            py + 3, COLOR_DIM);
    }
}
