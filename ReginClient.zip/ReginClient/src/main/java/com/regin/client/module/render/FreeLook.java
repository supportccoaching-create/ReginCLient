package com.regin.client.module.render;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class FreeLook extends Module {
    public float savedYaw, savedPitch;
    public float freeYaw, freePitch;

    public FreeLook() { super("FreeLook", "Unlocks camera rotation without turning player body", Category.RENDER); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        savedYaw   = mc.player.getYaw();
        savedPitch = mc.player.getPitch();
        freeYaw    = savedYaw;
        freePitch  = savedPitch;
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.setYaw(savedYaw);
        mc.player.setPitch(savedPitch);
    }
    // Mouse delta intercepted in MouseMixin, applied to freeYaw/freePitch
}
