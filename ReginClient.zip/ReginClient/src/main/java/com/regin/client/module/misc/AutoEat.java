package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.FoodItem;
import net.minecraft.item.ItemStack;

public class AutoEat extends Module {
    private final Setting<Integer> threshold = register(new Setting<>("Threshold", 16, 1, 20));
    private boolean eating = false;

    public AutoEat() { super("AutoEat", "Automatically eats food when hunger drops", Category.MISC); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (eating) {
            mc.options.useKey.setPressed(false);
            eating = false;
            return;
        }

        if (mc.player.getHungerManager().getFoodLevel() > threshold.getValue()) return;

        int bestSlot = -1, bestValue = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!(s.getItem() instanceof FoodItem)) continue;
            int val = s.getItem().getFoodComponent() != null
                ? s.getItem().getFoodComponent().getHunger() : 0;
            if (val > bestValue) { bestValue = val; bestSlot = i; }
        }
        if (bestSlot == -1) return;

        mc.player.getInventory().selectedSlot = bestSlot;
        mc.options.useKey.setPressed(true);
        eating = true;
    }
}
