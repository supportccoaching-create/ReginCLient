package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

public class AutoReconnect extends Module {
    public final Setting<Integer> delay = register(new Setting<>("Delay", 5, 1, 60));

    public AutoReconnect() { super("AutoReconnect", "Reconnects after disconnect after a delay", Category.MISC); }
    // Mixin on DisconnectedScreen: schedule reconnect after delay.getValue() seconds
}
