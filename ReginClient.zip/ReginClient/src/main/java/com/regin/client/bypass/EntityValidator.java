package com.regin.client.bypass;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Filters fake/bot entities before rendering ESP.
 *
 * Strategy:
 *   1. Track which UUIDs appeared in PlayerListS2CPacket (real players).
 *   2. Track metadata consistency: real players have consistent skin, name, team data.
 *   3. Check packet sequence: fake entities often lack initial spawn metadata packets.
 *   4. Movement plausibility: bots often teleport or have impossible velocity.
 */
public class EntityValidator {

    // UUIDs confirmed via tab-list (PlayerListS2CPacket)
    private final Set<UUID> confirmedPlayers = ConcurrentHashMap.newKeySet();

    // Per-entity packet history: UUID -> tick of last position update
    private final Map<UUID, Long> lastPositionTick = new ConcurrentHashMap<>();

    // Per-entity spawn tick
    private final Map<UUID, Long> spawnTick = new ConcurrentHashMap<>();

    // Track teleport anomalies per entity
    private final Map<UUID, Integer> teleportCount = new ConcurrentHashMap<>();

    // Previous positions for velocity plausibility
    private final Map<UUID, double[]> prevPositions = new ConcurrentHashMap<>();

    private long currentTick = 0;

    // ── Called from PacketEvent on PlayerListS2CPacket (ADD_PLAYER action) ────
    public void onPlayerListAdd(UUID uuid) {
        confirmedPlayers.add(uuid);
    }

    // ── Called from PacketEvent on PlayerListS2CPacket (REMOVE_PLAYER action) ─
    public void onPlayerListRemove(UUID uuid) {
        confirmedPlayers.remove(uuid);
        lastPositionTick.remove(uuid);
        spawnTick.remove(uuid);
        teleportCount.remove(uuid);
        prevPositions.remove(uuid);
    }

    // ── Called when entity spawns ─────────────────────────────────────────────
    public void onEntitySpawn(UUID uuid) {
        spawnTick.put(uuid, currentTick);
        teleportCount.put(uuid, 0);
    }

    // ── Called every tick for position updates ────────────────────────────────
    public void onPositionUpdate(UUID uuid, double x, double y, double z) {
        lastPositionTick.put(uuid, currentTick);

        double[] prev = prevPositions.get(uuid);
        if (prev != null) {
            double dx   = x - prev[0];
            double dy   = y - prev[1];
            double dz   = z - prev[2];
            double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);

            // Teleport threshold: > 8 blocks per tick is suspicious
            if (dist > 8.0) {
                teleportCount.merge(uuid, 1, Integer::sum);
            }
        }
        prevPositions.put(uuid, new double[]{x, y, z});
    }

    public void tick() { currentTick++; }

    // ── Main validation method ────────────────────────────────────────────────
    /**
     * Returns true if the entity is likely a real player, false if bot/fake.
     */
    public boolean isValid(Entity entity) {
        if (!(entity instanceof PlayerEntity)) return true; // non-players always valid

        UUID uuid = entity.getUuid();

        // Rule 1: must be in tab-list
        if (!confirmedPlayers.contains(uuid)) return false;

        // Rule 2: must have received at least one position update in last 20 ticks
        Long lastTick = lastPositionTick.get(uuid);
        if (lastTick == null || (currentTick - lastTick) > 20) return false;

        // Rule 3: too many teleport anomalies = bot (threshold: 3 in lifetime)
        int teleports = teleportCount.getOrDefault(uuid, 0);
        if (teleports > 3) return false;

        // Rule 4: entity name must match tab-list entry
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(uuid);
            if (entry == null) return false;

            // Name consistency check
            String tabName    = entry.getProfile().getName();
            String entityName = entity.getName().getString();
            if (!tabName.equals(entityName)) return false;

            // Ping sanity: fake entities sometimes have 0 or negative ping
            if (entry.getLatency() < 0) return false;
        }

        return true;
    }

    public Set<UUID> getConfirmedPlayers() {
        return Collections.unmodifiableSet(confirmedPlayers);
    }
}
