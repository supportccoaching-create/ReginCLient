package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;

public class MaceSwap extends Module {
    public MaceSwap() {
        super("MaceSwap", "Swaps to mace on fall for smash attack, swaps back after hit", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        boolean falling = mc.player.getVelocity().y < -0.1 && !mc.player.isOnGround();
        if (!falling) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.MACE) {
                mc.player.getInventory().selectedSlot = i;
                return;
            }
        }
    }
}
