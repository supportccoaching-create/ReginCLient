package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class SkinProtect extends Module {
    public SkinProtect() { super("SkinProtect", "Blocks outbound skin texture requests for own player", Category.MISC); }
    // Mixin on SkinManager#fetchSkin: skip request when UUID matches local player
}
