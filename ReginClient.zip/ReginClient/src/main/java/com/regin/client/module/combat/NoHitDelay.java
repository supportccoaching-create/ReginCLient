package com.regin.client.module.combat;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class NoHitDelay extends Module {
    public NoHitDelay() {
        super("NoHitDelay", "Removes attack cooldown client-side", Category.COMBAT);
    }
    // Mixin on PlayerEntity#getAttackCooldownProgress -> return 1.0f when enabled
    // Mixin on MinecraftClient#doAttack -> skip cooldown check when enabled
}
