package com.regin.client.core;

import com.regin.client.config.ConfigManager;
import com.regin.client.event.EventBus;
import com.regin.client.input.KeybindManager;
import com.regin.client.module.ModuleManager;
import com.regin.client.command.CommandManager;
import com.regin.client.gui.ClickGUI;

public class Client {

    public static final Client INSTANCE = new Client();

    public EventBus      eventBus;
    public ModuleManager moduleManager;
    public ConfigManager configManager;
    public KeybindManager keybindManager;
    public CommandManager commandManager;
    public ClickGUI       clickGUI;

    private Client() {}

    public void init() {
        eventBus      = new EventBus();
        moduleManager = new ModuleManager();
        configManager = new ConfigManager();
        keybindManager = new KeybindManager();
        commandManager = new CommandManager();
        clickGUI      = new ClickGUI();

        moduleManager.registerAll();
        configManager.load();
        commandManager.registerAll();
    }

    public void shutdown() {
        configManager.save();
    }
}
