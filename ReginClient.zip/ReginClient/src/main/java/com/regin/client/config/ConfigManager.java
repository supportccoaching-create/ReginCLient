package com.regin.client.config;

import com.google.gson.*;
import com.regin.client.core.Client;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

import java.io.*;
import java.nio.file.*;

public class ConfigManager {

    private static final Path CONFIG_DIR  = Paths.get("regin");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve("modules.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public void load() {
        if (!Files.exists(CONFIG_FILE)) return;
        try (Reader r = Files.newBufferedReader(CONFIG_FILE)) {
            JsonObject root = gson.fromJson(r, JsonObject.class);
            if (root == null) return;

            for (Module module : Client.INSTANCE.moduleManager.getAll()) {
                if (!root.has(module.getName())) continue;
                JsonObject obj = root.getAsJsonObject(module.getName());

                // enabled state
                if (obj.has("enabled") && obj.get("enabled").getAsBoolean()) {
                    module.setEnabled(true);
                }
                // keybind
                if (obj.has("key")) {
                    module.setKey(obj.get("key").getAsInt());
                }
                // settings
                if (obj.has("settings")) {
                    JsonObject settings = obj.getAsJsonObject("settings");
                    for (Setting<?> setting : module.getSettings()) {
                        if (!settings.has(setting.getName())) continue;
                        loadSetting(setting, settings.get(setting.getName()));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_DIR);
            JsonObject root = new JsonObject();

            for (Module module : Client.INSTANCE.moduleManager.getAll()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("enabled", module.isEnabled());
                obj.addProperty("key",     module.getKey());

                JsonObject settingsObj = new JsonObject();
                for (Setting<?> s : module.getSettings()) {
                    settingsObj.add(s.getName(), valueToJson(s.getValue()));
                }
                obj.add("settings", settingsObj);
                root.add(module.getName(), obj);
            }

            try (Writer w = Files.newBufferedWriter(CONFIG_FILE)) {
                gson.toJson(root, w);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private void loadSetting(Setting<?> setting, JsonElement el) {
        try {
            Object val = setting.getValue();
            Object parsed;
            if      (val instanceof Boolean) parsed = el.getAsBoolean();
            else if (val instanceof Integer) parsed = el.getAsInt();
            else if (val instanceof Double)  parsed = el.getAsDouble();
            else if (val instanceof Float)   parsed = el.getAsFloat();
            else if (val instanceof Long)    parsed = el.getAsLong();
            else                             parsed = el.getAsString();
            ((Setting<Object>) setting).setValue(parsed);
        } catch (Exception ignored) {}
    }

    private JsonElement valueToJson(Object val) {
        if (val instanceof Boolean b) return new JsonPrimitive(b);
        if (val instanceof Number  n) return new JsonPrimitive(n);
        return new JsonPrimitive(val.toString());
    }
}
