package com.regin.client.module.render;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

public class RealHitBox extends Module {
    public RealHitBox() { super("RealHitBox", "Renders actual server-side hitboxes without interpolation", Category.RENDER); }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            // RenderUtils.drawBox(e.matrixStack, entity.getBoundingBox(), 0xFFA020F0)
        }
    }
}
