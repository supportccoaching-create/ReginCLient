package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class TriggerBot extends Module {
    private final Setting<Integer> delay = register(new Setting<>("Delay", 2, 0, 10));
    private int tick = 0;

    public TriggerBot() {
        super("TriggerBot", "Auto-attacks entity when crosshair is on it", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (tick++ < delay.getValue()) return;
        tick = 0;
        if (mc.targetedEntity instanceof LivingEntity le && !le.isDead()) {
            mc.interactionManager.attackEntity(mc.player, le);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
