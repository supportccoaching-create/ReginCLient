package com.regin.client.event.events;

import com.regin.client.event.Event;
import net.minecraft.network.packet.Packet;

public class PacketEvent extends Event {
    public enum Direction { SEND, RECEIVE }

    public final Direction direction;
    public       Packet<?> packet;

    public PacketEvent(Direction dir, Packet<?> pkt) {
        this.direction = dir;
        this.packet    = pkt;
    }
}
