package com.regin.client.mixin;

import com.regin.client.core.Client;
import com.regin.client.event.events.PacketEvent;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class NetworkHandlerMixin {

    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        if (Client.INSTANCE.eventBus == null) return;
        PacketEvent event = new PacketEvent(PacketEvent.Direction.SEND, packet);
        Client.INSTANCE.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }
}
