package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;

public class AnchorMacro extends Module {
    private final Setting<Integer> delay = register(new Setting<>("Delay", 1, 0, 10));
    private int tick = 0;

    public AnchorMacro() {
        super("AnchorMacro", "Automatically activates respawn anchors for explosions", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (tick++ < delay.getValue()) return;
        tick = 0;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.RESPAWN_ANCHOR) {
                mc.player.getInventory().selectedSlot = i;
                break;
            }
        }
    }
}
