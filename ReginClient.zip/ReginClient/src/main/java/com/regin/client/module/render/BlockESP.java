package com.regin.client.module.render;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.awt.Color;

public class BlockESP extends Module {
    private final Setting<String>  blockId = register(new Setting<>("Block", "minecraft:chest"));
    private final Setting<Integer> range   = register(new Setting<>("Range",  16, 1, 64));

    public BlockESP() { super("BlockESP", "Highlights specific block type in world", Category.RENDER); }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        var target = net.minecraft.registry.Registries.BLOCK
            .get(net.minecraft.util.Identifier.of(blockId.getValue()));
        BlockPos center = mc.player.getBlockPos();
        int r = range.getValue();

        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = center.add(x, y, z);
                    if (mc.world.getBlockState(pos).getBlock() == target)
                        ; // RenderUtils.drawBox(e.matrixStack, pos, new Color(0xA020F0))
                }
    }
}
