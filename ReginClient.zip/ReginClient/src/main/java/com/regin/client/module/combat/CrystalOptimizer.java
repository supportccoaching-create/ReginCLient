package com.regin.client.module.combat;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

public class CrystalOptimizer extends Module {
    private final Setting<Integer> maxPerTick = register(new Setting<>("MaxPerTick", 3, 1, 10));

    public CrystalOptimizer() {
        super("CrystalOptimizer", "Throttles crystal place/break per tick to reduce lag", Category.COMBAT);
    }
    // Hooks into AutoCrystal — when both are enabled, AutoCrystal checks this module's maxPerTick
}
