package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class AutoShulkerBuy extends Module {
    private final Setting<Integer> minAmount = register(new Setting<>("MinAmount", 2, 1, 27));

    public AutoShulkerBuy() {
        super("AutoShulkerBuy", "Buys shulker boxes when stock drops below minimum", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        int count = 0;
        for (int i = 0; i < 36; i++) {
            Item item = mc.player.getInventory().getStack(i).getItem();
            if (item instanceof BlockItem bi
                && bi.getBlock() instanceof net.minecraft.block.ShulkerBoxBlock)
                count++;
        }
        if (count < minAmount.getValue())
            mc.getNetworkHandler().sendChatCommand("buy shulker");
    }
}

// ── TunnelBaseFinder ──────────────────────────────────────────────────────────
