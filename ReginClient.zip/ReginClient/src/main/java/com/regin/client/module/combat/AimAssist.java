package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {

    private final Setting<Double> range      = register(new Setting<>("Range",      4.5, 1.0, 8.0));
    private final Setting<Double> horizontal = register(new Setting<>("Horizontal", 2.5, 0.1, 10.0));
    private final Setting<Double> vertical   = register(new Setting<>("Vertical",   2.5, 0.1, 10.0));
    private final Setting<Boolean> playersOnly = register(new Setting<>("PlayersOnly", true));
    private final Setting<Boolean> throughWalls = register(new Setting<>("ThroughWalls", false));

    public AimAssist() {
        super("AimAssist", "Smoothly rotates toward nearest entity", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        Entity target = findTarget(mc);
        if (target == null) return;

        rotateToward(mc, target);
    }

    private Entity findTarget(MinecraftClient mc) {
        Entity closest = null;
        double closestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            if (playersOnly.getValue() && !(e instanceof PlayerEntity)) continue;
            if (!(e instanceof LivingEntity le)) continue;
            if (le.isDead() || le.getHealth() <= 0) continue;

            double dist = mc.player.distanceTo(e);
            if (dist > range.getValue()) continue;

            if (!throughWalls.getValue()) {
                // simple line-of-sight check via raycast
                Vec3d start = mc.player.getEyePos();
                Vec3d end   = e.getEyePos();
                if (mc.world.raycastBlock(start, end, null) != null) continue;
            }

            if (dist < closestDist) {
                closestDist = dist;
                closest     = e;
            }
        }
        return closest;
    }

    private void rotateToward(MinecraftClient mc, Entity target) {
        Vec3d eyes   = mc.player.getEyePos();
        Vec3d tPos   = target.getEyePos();
        double dx    = tPos.x - eyes.x;
        double dy    = tPos.y - eyes.y;
        double dz    = tPos.z - eyes.z;
        double dist  = Math.sqrt(dx * dx + dz * dz);

        float targetYaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));

        float currentYaw   = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();

        float yawDiff   = wrapDegrees(targetYaw - currentYaw);
        float pitchDiff = targetPitch - currentPitch;

        // smooth step — clamp by speed setting
        float hs = horizontal.getValue().floatValue();
        float vs = vertical.getValue().floatValue();

        float newYaw   = currentYaw   + clamp(yawDiff,   -hs, hs);
        float newPitch = currentPitch + clamp(pitchDiff, -vs, vs);
        newPitch = clamp(newPitch, -90f, 90f);

        mc.player.setYaw(newYaw);
        mc.player.setPitch(newPitch);
    }

    private float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f)  d -= 360f;
        if (d < -180f)  d += 360f;
        return d;
    }

    private float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
