package com.regin.client.module.basefinding;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import java.awt.Color;
import java.util.*;

public class LightFinder extends Module {
    private final Setting<Integer> minLevel = register(new Setting<>("MinLevel", 8, 1, 15));
    private final Setting<Integer> radius   = register(new Setting<>("Radius",  64, 16, 256));

    public LightFinder() {
        super("LightFinder", "Finds artificially lit areas that may indicate player bases", Category.BASEFINDING);
    }

    // suspicious light: underground area with light level > minLevel but no natural source
    private final Set<BlockPos> suspiciousLights = new HashSet<>();

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        suspiciousLights.clear();
        BlockPos center = mc.player.getBlockPos();
        int r = radius.getValue();

        for (int x = -r; x <= r; x += 4) {
            for (int y = -32; y <= 0; y += 2) {
                for (int z = -r; z <= r; z += 4) {
                    BlockPos pos = center.add(x, y, z);
                    int light = mc.world.getLightLevel(pos);
                    if (light >= minLevel.getValue()) {
                        // check if natural light source exists nearby
                        if (!hasNaturalSource(mc, pos)) {
                            suspiciousLights.add(pos);
                        }
                    }
                }
            }
        }
    }

    private boolean hasNaturalSource(MinecraftClient mc, BlockPos pos) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    var block = mc.world.getBlockState(pos.add(dx, dy, dz)).getBlock();
                    if (block.equals(net.minecraft.block.Blocks.LAVA) ||
                        block.equals(net.minecraft.block.Blocks.MAGMA_BLOCK) ||
                        block.equals(net.minecraft.block.Blocks.GLOWSTONE)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

// ── SusChunkFinder ────────────────────────────────────────────────────────────
