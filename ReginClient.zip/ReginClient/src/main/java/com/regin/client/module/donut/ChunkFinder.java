package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class ChunkFinder extends Module {
    private final Setting<Integer> threshold = register(new Setting<>("Threshold", 10, 1, 64));

    public ChunkFinder() {
        super("ChunkFinder", "Finds chunks with abnormally high block-entity density", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        java.util.Map<ChunkPos, Integer> counts = new java.util.HashMap<>();
        mc.world.blockEntities.forEach(be ->
            counts.merge(new ChunkPos(be.getPos()), 1, Integer::sum));

        counts.forEach((cp, cnt) -> {
            if (cnt >= threshold.getValue()) {
                mc.player.sendMessage(
                    net.minecraft.text.Text.literal(
                        "§5[ChunkFinder] §dDense chunk " + cp + " (" + cnt + ")"), false);
            }
        });
    }
}

// ── PrimeChunkFinder ──────────────────────────────────────────────────────────
