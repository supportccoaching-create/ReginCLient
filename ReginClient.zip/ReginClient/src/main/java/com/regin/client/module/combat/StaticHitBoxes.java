package com.regin.client.module.combat;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class StaticHitBoxes extends Module {
    // UUID -> last known bounding box
    private final Map<UUID, Box> frozenBoxes = new ConcurrentHashMap<>();

    public StaticHitBoxes() {
        super("StaticHitBoxes", "Freezes entity hitboxes at last known position for lag comp", Category.COMBAT);
    }

    public void updateBox(Entity entity) {
        if (!isEnabled()) return;
        frozenBoxes.put(entity.getUuid(), entity.getBoundingBox());
    }

    public Box getBox(Entity entity) {
        return frozenBoxes.getOrDefault(entity.getUuid(), entity.getBoundingBox());
    }

    @Override
    public void onDisable() { frozenBoxes.clear(); }
}
