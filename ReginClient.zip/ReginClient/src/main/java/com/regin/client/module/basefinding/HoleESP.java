package com.regin.client.module.basefinding;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import java.awt.Color;
import java.util.*;

public public class HoleESP extends Module {
    private final Setting<Integer> range = register(new Setting<>("Range", 10, 1, 32));

    public HoleESP() {
        super("HoleESP", "Highlights safe holes (surrounded by obsidian/bedrock) for crystal PvP", Category.BASEFINDING);
    }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        BlockPos center = mc.player.getBlockPos();
        int r = range.getValue();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = -4; y <= 4; y++) {
                    BlockPos pos = center.add(x, y, z);
                    if (isSafeHole(mc, pos)) {
                        drawHoleBox(e, pos);
                    }
                }
            }
        }
    }

    private boolean isSafeHole(MinecraftClient mc, BlockPos pos) {
        if (!mc.world.getBlockState(pos).isAir()) return false;
        if (!mc.world.getBlockState(pos.up()).isAir()) return false;

        // all 4 sides and below must be obsidian or bedrock
        BlockPos[] sides = {
            pos.north(), pos.south(), pos.east(), pos.west(), pos.down()
        };
        for (BlockPos side : sides) {
            var block = mc.world.getBlockState(side).getBlock();
            if (!block.equals(net.minecraft.block.Blocks.OBSIDIAN) &&
                !block.equals(net.minecraft.block.Blocks.BEDROCK)) {
                return false;
            }
        }
        return true;
    }

    private void drawHoleBox(RenderEvent e, BlockPos pos) {
        // render green box at pos
    }
}

// ── LightFinder ───────────────────────────────────────────────────────────────
