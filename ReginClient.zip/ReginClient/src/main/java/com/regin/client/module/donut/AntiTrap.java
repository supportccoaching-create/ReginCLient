package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public public class AntiTrap extends Module {
    private final Setting<Boolean> autoEscape = register(new Setting<>("AutoEscape", true));

    public AntiTrap() {
        super("AntiTrap", "Detects when player is surrounded and attempts escape", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        BlockPos pos  = mc.player.getBlockPos();
        int      solid = 0;
        for (BlockPos off : new BlockPos[]{
            pos.north(), pos.south(), pos.east(), pos.west(), pos.up(), pos.down()
        }) {
            if (!mc.world.getBlockState(off).isAir()) solid++;
        }

        if (solid >= 5) {
            mc.player.sendMessage(
                net.minecraft.text.Text.literal("§5[ReginClient] §dTrap detected!"), true);
            if (autoEscape.getValue()) {
                mc.interactionManager.updateBlockBreakingProgress(
                    pos.up(), net.minecraft.util.math.Direction.DOWN);
            }
        }
    }
}

// ── AuctionSniper ─────────────────────────────────────────────────────────────
