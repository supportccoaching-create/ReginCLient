package com.regin.client.module.render;

import com.regin.client.bypass.EntityValidator;
import com.regin.client.core.Client;
import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

import java.awt.Color;

public class PlayerESP extends Module {
    private final Setting<Boolean> box     = register(new Setting<>("Box",     true));
    private final Setting<Boolean> tracers = register(new Setting<>("Tracers", false));
    private final Setting<Boolean> health  = register(new Setting<>("Health",  true));
    private final Setting<Double>  range   = register(new Setting<>("Range",   64.0, 1.0, 256.0));

    public PlayerESP() { super("PlayerESP", "Draws boxes/tracers around players", Category.RENDER); }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        EntityValidator validator = new EntityValidator();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!validator.isValid(player)) continue;
            if (mc.player.distanceTo(player) > range.getValue()) continue;

            Color color = getHealthColor(player.getHealth(), player.getMaxHealth());
            if (box.getValue())     drawEntityBox(e, player, color);
            if (tracers.getValue()) drawTracer(e, player, color);
        }
    }

    private Color getHealthColor(float hp, float max) {
        float ratio = hp / max;
        return new Color((int)((1 - ratio) * 255), (int)(ratio * 200), 0, 200);
    }

    private void drawEntityBox(RenderEvent e, Entity entity, Color color) {
        // RenderUtils.drawBox(e.matrixStack, entity.getBoundingBox(), color)
    }

    private void drawTracer(RenderEvent e, Entity entity, Color color) {
        // RenderUtils.drawTracer(e.matrixStack, entity.getEyePos(), color)
    }
}
