package com.regin.client.module;

import com.regin.client.module.combat.*;
import com.regin.client.module.movement.*;
import com.regin.client.module.render.*;
import com.regin.client.module.misc.*;
import com.regin.client.module.player.*;
import com.regin.client.module.exploit.*;
import com.regin.client.module.donut.*;
import com.regin.client.module.basefinding.*;

import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerAll() {
        // ── Combat ────────────────────────────────────────────────────────────
        register(
            new AimAssist(),
            new AnchorMacro(),
            new AutoDoubleHand(),
            new AutoCrystal(),
            new AutoHitCrystal(),
            new AutoInvTotem(),
            new AutoJumpReset(),
            new AutoTotem(),
            new CrystalOptimizer(),
            new DoubleAnchor(),
            new ElytraSwap(),
            new HitBox(),
            new HoverTotem(),
            new TotemOffhand(),
            new MaceSwap(),
            new SpearSwap(),
            new NoHitDelay(),
            new ShieldBreaker(),
            new StaticHitBoxes(),
            new TriggerBot(),
            new MaceBomber()
        );

        // ── Movement ──────────────────────────────────────────────────────────
        register(
            new Sprint(),
            new Speed(),
            new Flight(),
            new LongJump(),
            new Step(),
            new NoSlow(),
            new SafeWalk(),
            new Jesus()
        );

        // ── Render ────────────────────────────────────────────────────────────
        register(
            new OreSim(),
            new Fullbright(),
            new SwingSpeed(),
            new JumpCircles(),
            new HUD(),
            new PlayerESP(),
            new StorageESP(),
            new BlockESP(),
            new TargetHUD(),
            new RealHitBox(),
            new FreeLook()
        );

        // ── Misc ──────────────────────────────────────────────────────────────
        register(
            new AutoClicker(),
            new AutoEat(),
            new AutoFirework(),
            new AutoLog(),
            new AutoLoot(),
            new AutoMine(),
            new AutoTool(),
            new CordSnapper(),
            new ElytraGlide(),
            new FastPlace(),
            new Freecam(),
            new KeyPearl(),
            new KeyWindCharge(),
            new NameProtect(),
            new SkinProtect(),
            new AutoReconnect()
        );

        // ── Player ────────────────────────────────────────────────────────────
        register(
            new AutoArmor(),
            new AutoRespawn(),
            new NoFall()
        );

        // ── Exploit ───────────────────────────────────────────────────────────
        register(
            new PacketFly(),
            new Blink(),
            new Phase()
        );

        // ── Donut ─────────────────────────────────────────────────────────────
        register(
            new AntiTrap(),
            new AuctionSniper(),
            new AutoSell(),
            new AutoSpawnerSell(),
            new ItemDropper(),
            new NetheriteFinder(),
            new RtpBaseFinder(),
            new AutoShulkerBuy(),
            new TunnelBaseFinder(),
            new SpawnerProtect(),
            new ChunkFinder(),
            new PrimeChunkFinder()
        );

        // ── Base Finding ──────────────────────────────────────────────────────
        register(
            new SeedChunkFinder(),
            new HoleESP(),
            new LightFinder(),
            new SusChunkFinder(),
            new SuspiciousESP()
        );
    }

    private void register(Module... mods) {
        modules.addAll(Arrays.asList(mods));
    }

    public Module get(String name) {
        return modules.stream()
                      .filter(m -> m.getName().equalsIgnoreCase(name))
                      .findFirst().orElse(null);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream()
                          .filter(m -> m.getClass() == clazz)
                          .findFirst().orElse(null);
    }

    public List<Module> getByCategory(Category cat) {
        return modules.stream()
                      .filter(m -> m.getCategory() == cat)
                      .collect(Collectors.toList());
    }

    public List<Module> getAll()     { return Collections.unmodifiableList(modules); }
    public List<Module> getEnabled() {
        return modules.stream().filter(Module::isEnabled).collect(Collectors.toList());
    }

    public void onKeyPress(int key) {
        modules.stream()
               .filter(m -> m.getKey() == key)
               .forEach(Module::toggle);
    }
}
