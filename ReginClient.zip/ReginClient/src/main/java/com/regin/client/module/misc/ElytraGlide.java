package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class ElytraGlide extends Module {
    private final Setting<Double> speed = register(new Setting<>("Speed", 1.5, 0.5, 5.0));

    public ElytraGlide() { super("ElytraGlide", "Smooth elytra flight with configurable speed", Category.MISC); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.isFallFlying()) return;
        double yaw   = Math.toRadians(mc.player.getYaw());
        double pitch = Math.toRadians(mc.player.getPitch());
        double spd   = speed.getValue();
        mc.player.setVelocity(
            -Math.sin(yaw) * Math.cos(pitch) * spd,
            -Math.sin(pitch) * spd,
             Math.cos(yaw) * Math.cos(pitch) * spd);
    }
}
