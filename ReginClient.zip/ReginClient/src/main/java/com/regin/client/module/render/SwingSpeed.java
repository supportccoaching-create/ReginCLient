package com.regin.client.module.render;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;

public class SwingSpeed extends Module {
    public final Setting<Integer> speed = register(new Setting<>("Speed", 4, 1, 20));

    public SwingSpeed() { super("SwingSpeed", "Changes hand swing animation speed", Category.RENDER); }
    // Mixin on PlayerEntity#getHandSwingDuration -> return speed.getValue()
}
