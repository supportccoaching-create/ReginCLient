package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.AxeItem;

public class ShieldBreaker extends Module {
    public ShieldBreaker() {
        super("ShieldBreaker", "Auto-switches to axe to break enemy shields", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!(mc.targetedEntity instanceof net.minecraft.entity.LivingEntity le)) return;
        if (!le.isBlocking()) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                mc.player.getInventory().selectedSlot = i;
                return;
            }
        }
    }
}
