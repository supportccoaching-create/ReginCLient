package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.ItemEntity;

public class AutoLoot extends Module {
    private final Setting<Double> range = register(new Setting<>("Range", 3.0, 1.0, 6.0));

    public AutoLoot() { super("AutoLoot", "Automatically moves toward nearby items", Category.MISC); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        mc.world.getEntities().forEach(entity -> {
            if (!(entity instanceof ItemEntity)) return;
            if (mc.player.distanceTo(entity) > range.getValue()) return;
            mc.player.setPos(entity.getX(), mc.player.getY(), entity.getZ());
        });
    }
}
