package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class AuctionSniper extends Module {
    private final Setting<String>  targetItem = register(new Setting<>("Item",     ""));
    private final Setting<Double>  maxPrice   = register(new Setting<>("MaxPrice", 1000000.0, 1.0, 1.0e9));
    private final Setting<Boolean> autoBuy    = register(new Setting<>("AutoBuy",  false));

    public AuctionSniper() {
        super("AuctionSniper", "Monitors chat for target items below max price", Category.DONUT);
    }

    @EventListener
    public void onPacket(PacketEvent e) {
        if (e.direction != PacketEvent.Direction.RECEIVE) return;
        if (!(e.packet instanceof ChatMessageS2CPacket chatPkt)) return;

        String msg = chatPkt.body().content();
        if (targetItem.getValue().isEmpty()) return;
        if (!msg.contains(targetItem.getValue())) return;

        double price = parsePrice(msg);
        if (price <= 0 || price > maxPrice.getValue()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.sendMessage(
            net.minecraft.text.Text.literal("§5[AuctionSniper] §dFound: " + msg), false);

        if (autoBuy.getValue()) {
            mc.getNetworkHandler().sendChatCommand("ah buy");
        }
    }

    private double parsePrice(String msg) {
        java.util.regex.Matcher m =
            java.util.regex.Pattern.compile("[\\d,]+").matcher(msg);
        String last = "";
        while (m.find()) last = m.group();
        try { return last.isEmpty() ? -1 : Double.parseDouble(last.replace(",", "")); }
        catch (NumberFormatException ex) { return -1; }
    }
}

// ── AutoSell ──────────────────────────────────────────────────────────────────
