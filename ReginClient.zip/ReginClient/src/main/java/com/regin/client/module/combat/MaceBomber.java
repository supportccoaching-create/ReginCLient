package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

public class MaceBomber extends Module {
    private final Setting<Double> height    = register(new Setting<>("Height",    10.0, 3.0, 40.0));
    private final Setting<Double> range     = register(new Setting<>("Range",      5.0, 1.0, 10.0));

    private enum Phase { IDLE, ASCENDING, DIVING }
    private Phase phase  = Phase.IDLE;
    private double targetX, targetY, targetZ;

    public MaceBomber() {
        super("MaceBomber", "Flies above target and mace-bombs them from height", Category.COMBAT);
    }

    @Override
    public void onDisable() { phase = Phase.IDLE; }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        PlayerEntity target = findTarget(mc);

        switch (phase) {
            case IDLE -> {
                if (target == null) return;
                targetX = target.getX();
                targetY = target.getY() + height.getValue();
                targetZ = target.getZ();
                phase   = Phase.ASCENDING;
                // equip mace
                for (int i = 0; i < 9; i++) {
                    if (mc.player.getInventory().getStack(i).getItem() == Items.MACE) {
                        mc.player.getInventory().selectedSlot = i;
                        break;
                    }
                }
            }
            case ASCENDING -> {
                mc.player.getAbilities().allowFlying = true;
                mc.player.getAbilities().flying      = true;
                double dy = targetY - mc.player.getY();
                double dx = targetX - mc.player.getX();
                double dz = targetZ - mc.player.getZ();
                if (Math.abs(dy) < 0.5 && Math.sqrt(dx*dx+dz*dz) < 1.0) {
                    phase = Phase.DIVING;
                    mc.player.getAbilities().flying = false;
                } else {
                    mc.player.setVelocity(dx * 0.3, dy * 0.3, dz * 0.3);
                }
            }
            case DIVING -> {
                // free-fall — NoHitDelay + mace smash attack handled by attack mixin
                if (mc.player.isOnGround()) {
                    phase = Phase.IDLE;
                    mc.player.getAbilities().allowFlying = false;
                    mc.player.sendAbilitiesUpdate();
                    setEnabled(false);
                }
            }
        }
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        PlayerEntity closest = null;
        double minDist = range.getValue();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead()) continue;
            double d = mc.player.distanceTo(p);
            if (d < minDist) { minDist = d; closest = p; }
        }
        return closest;
    }
}
