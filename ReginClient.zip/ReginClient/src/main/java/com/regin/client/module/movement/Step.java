package com.regin.client.module.movement;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Step extends Module {
    private final Setting<Double> height = register(new Setting<>("Height", 1.0, 0.5, 2.5));

    public Step() { super("Step", "Allows stepping up blocks without jumping", Category.MOVEMENT); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.stepHeight = height.getValue().floatValue();
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.stepHeight = 0.6f;
    }
}
