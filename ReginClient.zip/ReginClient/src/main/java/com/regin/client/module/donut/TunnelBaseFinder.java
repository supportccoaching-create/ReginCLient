package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class TunnelBaseFinder extends Module {
    public TunnelBaseFinder() {
        super("TunnelBaseFinder", "Detects player-dug tunnels by analysing air corridors in stone", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        BlockPos center = mc.player.getBlockPos();
        for (int x = -16; x <= 16; x++) {
            for (int z = -16; z <= 16; z++) {
                for (int y = -64; y < 0; y++) {
                    BlockPos pos = center.add(x, y, z);
                    if (!mc.world.getBlockState(pos).isAir()) continue;
                    if (!mc.world.getBlockState(pos.up()).isAir()) continue;

                    // all four sides must be stone/deepslate — marks dug tunnel vs natural cave
                    int stoneWalls = 0;
                    for (BlockPos adj : new BlockPos[]{
                        pos.north(), pos.south(), pos.east(), pos.west()
                    }) {
                        var b = mc.world.getBlockState(adj).getBlock();
                        if (b == net.minecraft.block.Blocks.STONE
                         || b == net.minecraft.block.Blocks.DEEPSLATE)
                            stoneWalls++;
                    }
                    if (stoneWalls == 4) {
                        mc.player.sendMessage(
                            net.minecraft.text.Text.literal(
                                "§5[TunnelFinder] §dTunnel at " + pos.toShortString()), false);
                        return;
                    }
                }
            }
        }
    }
}

// ── SpawnerProtect ────────────────────────────────────────────────────────────
