package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class ItemDropper extends Module {
    private final Setting<String> dropItem = register(new Setting<>("Item", "minecraft:dirt"));

    public ItemDropper() {
        super("ItemDropper", "Auto-drops specified item type from inventory", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        var target = net.minecraft.registry.Registries.ITEM
            .get(net.minecraft.util.Identifier.of(dropItem.getValue()));

        for (int i = 9; i < 45; i++) {
            if (mc.player.playerScreenHandler.slots.get(i).getStack().getItem() != target) continue;
            mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId, i, 1,
                SlotActionType.THROW, mc.player);
        }
    }
}

// ── NetheriteFinder ───────────────────────────────────────────────────────────
