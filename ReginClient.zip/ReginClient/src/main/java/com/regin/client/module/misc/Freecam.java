package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class Freecam extends Module {
    public double camX, camY, camZ;
    public float  camYaw, camPitch;

    public Freecam() { super("Freecam", "Detaches camera from player body", Category.MISC); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        camX = mc.player.getX(); camY = mc.player.getY(); camZ = mc.player.getZ();
        camYaw = mc.player.getYaw(); camPitch = mc.player.getPitch();
    }
    // Camera entity spawned via mixin at camX/Y/Z, input routed to it while enabled
}
