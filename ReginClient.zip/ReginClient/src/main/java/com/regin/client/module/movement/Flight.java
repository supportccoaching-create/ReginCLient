package com.regin.client.module.movement;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Flight extends Module {
    private final Setting<Double> speed = register(new Setting<>("Speed", 1.0, 0.1, 10.0));

    public Flight() { super("Flight", "Enables creative-like flight", Category.MOVEMENT); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying      = true;
        mc.player.sendAbilitiesUpdate();
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = false;
        mc.player.getAbilities().flying      = false;
        mc.player.sendAbilitiesUpdate();
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.getAbilities().flySpeed = speed.getValue().floatValue() * 0.05f;
    }
}
