package com.regin.client.gui;

import com.regin.client.core.Client;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ClickGUI extends Screen {

    // ── Colors — purple palette ───────────────────────────────────────────────
    private static final int COLOR_PRIMARY     = 0xFFA020F0; // #A020F0
    private static final int COLOR_SECONDARY   = 0xFFE0B0FF; // #E0B0FF
    private static final int COLOR_BG          = 0xE6100010; // dark purple bg
    private static final int COLOR_PANEL_BG    = 0xE61A001A;
    private static final int COLOR_HEADER      = 0xFF7A00C8;
    private static final int COLOR_ENABLED     = 0xFFA020F0;
    private static final int COLOR_DISABLED    = 0xFF3A003A;
    private static final int COLOR_HOVER       = 0x33A020F0;
    private static final int COLOR_TEXT        = 0xFFE0B0FF;
    private static final int COLOR_TEXT_DIM    = 0xFF9060B0;
    private static final int COLOR_SLIDER_BG   = 0xFF2A002A;
    private static final int COLOR_SLIDER_FILL = 0xFFA020F0;

    // Panel layout
    private static final int PANEL_WIDTH  = 110;
    private static final int HEADER_H     = 14;
    private static final int MODULE_H     = 13;
    private static final int SETTING_H    = 12;
    private static final int PANEL_GAP    = 6;

    // Per-category panel state
    private final Map<Category, PanelState> panels = new LinkedHashMap<>();

    // Drag state
    private PanelState dragging    = null;
    private int        dragOffX    = 0;
    private int        dragOffY    = 0;

    // Expanded settings for a module
    private Module expandedModule  = null;

    public ClickGUI() {
        super(Text.literal("ReginClient"));
        int x = 5;
        for (Category cat : Category.values()) {
            panels.put(cat, new PanelState(cat, x, 5));
            x += PANEL_WIDTH + PANEL_GAP;
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // dim background
        ctx.fill(0, 0, this.width, this.height, 0x88000000);

        for (PanelState panel : panels.values()) {
            renderPanel(ctx, panel, mx, my);
        }

        // watermark
        ctx.drawTextWithShadow(client.textRenderer,
            Text.literal("§5Regin §dClient"), 4, this.height - 10, COLOR_SECONDARY);
    }

    private void renderPanel(DrawContext ctx, PanelState p, int mx, int my) {
        List<Module> modules = Client.INSTANCE.moduleManager.getByCategory(p.category);
        int totalH = HEADER_H;
        if (p.open) {
            for (Module m : modules) {
                totalH += MODULE_H;
                if (m == expandedModule) {
                    totalH += m.getSettings().size() * SETTING_H + 2;
                }
            }
        }

        // panel background
        ctx.fill(p.x, p.y, p.x + PANEL_WIDTH, p.y + totalH, COLOR_PANEL_BG);

        // header
        boolean hoverHeader = mx >= p.x && mx <= p.x + PANEL_WIDTH
                           && my >= p.y && my <= p.y + HEADER_H;
        ctx.fill(p.x, p.y, p.x + PANEL_WIDTH, p.y + HEADER_H,
                 hoverHeader ? COLOR_HEADER : COLOR_BG);

        // header accent line
        ctx.fill(p.x, p.y, p.x + PANEL_WIDTH, p.y + 1, COLOR_PRIMARY);

        String catName = p.category.displayName;
        ctx.drawTextWithShadow(client.textRenderer,
            Text.literal(catName), p.x + 3, p.y + 3, COLOR_SECONDARY);

        // collapse arrow
        String arrow = p.open ? "▾" : "▸";
        ctx.drawTextWithShadow(client.textRenderer,
            Text.literal("§5" + arrow), p.x + PANEL_WIDTH - 10, p.y + 3, COLOR_PRIMARY);

        if (!p.open) return;

        int ry = p.y + HEADER_H;
        for (Module m : modules) {
            boolean hoverMod = mx >= p.x && mx <= p.x + PANEL_WIDTH
                            && my >= ry   && my <= ry + MODULE_H;

            // module row background
            int rowBg = m.isEnabled() ? 0xFF1A0030 : 0xFF0D000D;
            if (hoverMod) rowBg = COLOR_HOVER;
            ctx.fill(p.x, ry, p.x + PANEL_WIDTH, ry + MODULE_H, rowBg);

            // enabled indicator strip on left
            if (m.isEnabled()) {
                ctx.fill(p.x, ry, p.x + 2, ry + MODULE_H, COLOR_PRIMARY);
            }

            // module name
            int nameColor = m.isEnabled() ? COLOR_SECONDARY : COLOR_TEXT_DIM;
            ctx.drawTextWithShadow(client.textRenderer,
                Text.literal(m.getName()), p.x + 5, ry + 2, nameColor);

            // settings expand arrow if has settings
            if (!m.getSettings().isEmpty()) {
                String sa = (m == expandedModule) ? "§5-" : "§8+";
                ctx.drawTextWithShadow(client.textRenderer,
                    Text.literal(sa), p.x + PANEL_WIDTH - 9, ry + 2, COLOR_TEXT_DIM);
            }

            ry += MODULE_H;

            // render settings if expanded
            if (m == expandedModule) {
                ry = renderSettings(ctx, m, p.x, ry, mx, my);
            }
        }

        // border lines
        drawBorder(ctx, p.x, p.y, PANEL_WIDTH, totalH, COLOR_PRIMARY, 0x66A020F0);
    }

    private int renderSettings(DrawContext ctx, Module m, int x, int y, int mx, int my) {
        for (Setting<?> s : m.getSettings()) {
            ctx.fill(x, y, x + PANEL_WIDTH, y + SETTING_H, 0xFF080008);

            Object val = s.getValue();

            if (val instanceof Boolean b) {
                // checkbox style
                ctx.fill(x + 3, y + 2, x + 9, y + 9,
                         b ? COLOR_PRIMARY : 0xFF3A003A);
                if (b) ctx.drawTextWithShadow(client.textRenderer,
                    Text.literal("✓"), x + 3, y + 1, 0xFFFFFFFF);
                ctx.drawTextWithShadow(client.textRenderer,
                    Text.literal(s.getName()), x + 12, y + 2, COLOR_TEXT_DIM);

            } else if (val instanceof Number n) {
                // slider
                float min = s.getMin() != null ? ((Number) s.getMin()).floatValue() : 0f;
                float max = s.getMax() != null ? ((Number) s.getMax()).floatValue() : 1f;
                float cur = n.floatValue();
                float pct = (cur - min) / (max - min);

                int barX  = x + 3;
                int barW  = PANEL_WIDTH - 6;
                int fillW = (int)(barW * pct);

                ctx.fill(barX, y + 6, barX + barW, y + 10, COLOR_SLIDER_BG);
                ctx.fill(barX, y + 6, barX + fillW, y + 10, COLOR_SLIDER_FILL);

                String label = s.getName() + ": " + formatNum(cur);
                ctx.drawTextWithShadow(client.textRenderer,
                    Text.literal(label), x + 3, y + 1, COLOR_TEXT_DIM);

            } else {
                // string value
                String label = s.getName() + ": " + val;
                ctx.drawTextWithShadow(client.textRenderer,
                    Text.literal(label), x + 3, y + 2, COLOR_TEXT_DIM);
            }

            y += SETTING_H;
        }
        // small gap after settings block
        ctx.fill(x, y, x + PANEL_WIDTH, y + 2, 0xFF1A001A);
        return y + 2;
    }

    private String formatNum(float v) {
        if (v == (int)v) return String.valueOf((int)v);
        return String.format("%.2f", v);
    }

    // ── Input ─────────────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int imx = (int)mx, imy = (int)my;

        for (PanelState p : panels.values()) {
            // header click — toggle open / start drag
            if (imx >= p.x && imx <= p.x + PANEL_WIDTH
             && imy >= p.y && imy <= p.y + HEADER_H) {
                if (btn == 0) {
                    p.open  = !p.open;
                } else if (btn == 2) {
                    dragging = p;
                    dragOffX = imx - p.x;
                    dragOffY = imy - p.y;
                }
                return true;
            }

            if (!p.open) continue;

            List<Module> modules = Client.INSTANCE.moduleManager.getByCategory(p.category);
            int ry = p.y + HEADER_H;

            for (Module m : modules) {
                if (imx >= p.x && imx <= p.x + PANEL_WIDTH
                 && imy >= ry  && imy <= ry + MODULE_H) {
                    if (btn == 0) {
                        m.toggle();
                    } else if (btn == 1) {
                        expandedModule = (expandedModule == m) ? null : m;
                    }
                    return true;
                }
                ry += MODULE_H;

                if (m == expandedModule) {
                    ry = handleSettingClick(m, p.x, ry, imx, imy, btn, mx);
                }
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @SuppressWarnings("unchecked")
    private int handleSettingClick(Module m, int x, int ry, int mx, int my, int btn, double rawMx) {
        for (Setting<?> s : m.getSettings()) {
            if (mx >= x && mx <= x + PANEL_WIDTH && my >= ry && my <= ry + SETTING_H) {
                Object val = s.getValue();
                if (val instanceof Boolean b) {
                    ((Setting<Boolean>) s).setValue(!b);
                } else if (val instanceof Number && s.getMin() != null) {
                    // click on slider — compute new value from X position
                    float pct   = (float)(rawMx - (x + 3)) / (PANEL_WIDTH - 6);
                    pct         = Math.max(0f, Math.min(1f, pct));
                    float min   = ((Number) s.getMin()).floatValue();
                    float max   = ((Number) s.getMax()).floatValue();
                    float newV  = min + pct * (max - min);
                    applyNumericSetting(s, newV);
                }
            }
            ry += SETTING_H;
        }
        return ry + 2;
    }

    @SuppressWarnings("unchecked")
    private void applyNumericSetting(Setting<?> s, float newV) {
        Object cur = s.getValue();
        if      (cur instanceof Double)  ((Setting<Double>)  s).setValue((double) newV);
        else if (cur instanceof Float)   ((Setting<Float>)   s).setValue(newV);
        else if (cur instanceof Integer) ((Setting<Integer>) s).setValue((int) newV);
        else if (cur instanceof Long)    ((Setting<Long>)    s).setValue((long) newV);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null && btn == 2) {
            dragging.x = (int)mx - dragOffX;
            dragging.y = (int)my - dragOffY;
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = null;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            MinecraftClient.getInstance().setScreen(null);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldPause() { return false; }

    // ── Border util ───────────────────────────────────────────────────────────
    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int outer, int inner) {
        ctx.fill(x,         y,     x + w,     y + 1,     outer);
        ctx.fill(x,         y + h - 1, x + w, y + h,     outer);
        ctx.fill(x,         y,     x + 1,     y + h,     outer);
        ctx.fill(x + w - 1, y,     x + w,     y + h,     outer);
        // inner glow
        ctx.fill(x + 1,     y + 1, x + w - 1, y + 2,     inner);
        ctx.fill(x + 1,     y + 1, x + 2,     y + h - 1, inner);
    }

    // ── Panel state ───────────────────────────────────────────────────────────
    private static class PanelState {
        final Category category;
        int     x, y;
        boolean open = false;

        PanelState(Category category, int x, int y) {
            this.category = category;
            this.x = x;
            this.y = y;
        }
    }
}
