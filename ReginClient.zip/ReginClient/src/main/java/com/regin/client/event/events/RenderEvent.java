package com.regin.client.event.events;

import com.regin.client.event.Event;
import net.minecraft.client.util.math.MatrixStack;

public class RenderEvent extends Event {
    public final MatrixStack matrixStack;
    public final float       partialTicks;

    public RenderEvent(MatrixStack ms, float pt) {
        this.matrixStack  = ms;
        this.partialTicks = pt;
    }
}
