package com.regin.client.module.render;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.awt.Color;

public class StorageESP extends Module {
    private final Setting<Boolean> chests   = register(new Setting<>("Chests",   true));
    private final Setting<Boolean> shulkers = register(new Setting<>("Shulkers", true));
    private final Setting<Boolean> barrels  = register(new Setting<>("Barrels",  true));
    private final Setting<Double>  range    = register(new Setting<>("Range",    32.0, 1.0, 128.0));

    public StorageESP() { super("StorageESP", "Highlights storage blocks in world", Category.RENDER); }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        mc.world.blockEntities.forEach(be -> {
            if (mc.player.getPos().distanceTo(Vec3d.of(be.getPos())) > range.getValue()) return;

            Color color = null;
            if (chests.getValue()   && be instanceof ChestBlockEntity)      color = new Color(0xFFAA00);
            if (shulkers.getValue() && be instanceof ShulkerBoxBlockEntity) color = new Color(0xA020F0);
            if (barrels.getValue()  && be instanceof BarrelBlockEntity)     color = new Color(0x8B4513);
            if (color == null) return;
            // RenderUtils.drawBox(e.matrixStack, be.getPos(), color)
        });
    }
}
