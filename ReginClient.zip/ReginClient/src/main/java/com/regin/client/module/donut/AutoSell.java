package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class AutoSell extends Module {
    private final Setting<String>  command  = register(new Setting<>("Command",  "/sell all"));
    private final Setting<Integer> interval = register(new Setting<>("Interval", 200, 10, 6000));
    private int tick = 0;

    public AutoSell() {
        super("AutoSell", "Runs sell command on configurable interval", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (tick++ < interval.getValue()) return;
        tick = 0;
        String cmd = command.getValue();
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        mc.getNetworkHandler().sendChatCommand(cmd);
    }
}

// ── AutoSpawnerSell ───────────────────────────────────────────────────────────
