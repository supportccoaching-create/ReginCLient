package com.regin.client.module.movement;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

public class Speed extends Module {
    private final Setting<Double> speed = register(new Setting<>("Speed", 1.3, 0.5, 5.0));

    public Speed() { super("Speed", "Increases movement speed", Category.MOVEMENT); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.isOnGround()) return;
        if (mc.player.input.movementForward == 0 && mc.player.input.movementSideways == 0) return;
        double yaw = Math.toRadians(mc.player.getYaw());
        double spd = speed.getValue();
        var cur = mc.player.getVelocity();
        mc.player.setVelocity(-Math.sin(yaw) * spd, cur.y, Math.cos(yaw) * spd);
    }
}
