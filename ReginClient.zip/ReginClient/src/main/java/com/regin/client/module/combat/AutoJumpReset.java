package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;

public class AutoJumpReset extends Module {
    public AutoJumpReset() {
        super("AutoJumpReset", "Resets fall damage by jumping at the right moment", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!mc.player.isOnGround() && mc.player.fallDistance > 2.0f)
            mc.player.jump();
    }
}
