package com.regin.client.setting;

public class Setting<T> {
    private final String name;
    private       T      value;
    private final T      min, max; // null for non-numeric

    public Setting(String name, T value) {
        this.name  = name;
        this.value = value;
        this.min   = null;
        this.max   = null;
    }

    public Setting(String name, T value, T min, T max) {
        this.name  = name;
        this.value = value;
        this.min   = min;
        this.max   = max;
    }

    public String getName()  { return name; }
    public T      getValue() { return value; }

    public void setValue(T value) {
        if (min != null && value instanceof Comparable) {
            @SuppressWarnings("unchecked")
            Comparable<T> cv = (Comparable<T>) value;
            if (cv.compareTo(min) < 0) { this.value = min; return; }
            if (cv.compareTo(max) > 0) { this.value = max; return; }
        }
        this.value = value;
    }

    public T getMin() { return min; }
    public T getMax() { return max; }
}
