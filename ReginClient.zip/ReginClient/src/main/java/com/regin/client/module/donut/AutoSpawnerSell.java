package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class AutoSpawnerSell extends Module {
    private final Setting<Integer> keepAmount = register(new Setting<>("Keep", 0, 0, 64));

    public AutoSpawnerSell() {
        super("AutoSpawnerSell", "Auto-sells spawners when over keep threshold", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        int count = 0;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.SPAWNER)
                count += mc.player.getInventory().getStack(i).getCount();
        }
        if (count > keepAmount.getValue())
            mc.getNetworkHandler().sendChatCommand("sell spawner");
    }
}

// ── ItemDropper ───────────────────────────────────────────────────────────────
