package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;

public class AutoTool extends Module {
    public AutoTool() { super("AutoTool", "Switches to best tool for targeted block", Category.MISC); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr)) return;
        var state = mc.world.getBlockState(bhr.getBlockPos());
        float best = -1; int bestSlot = -1;
        for (int i = 0; i < 9; i++) {
            float spd = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (spd > best) { best = spd; bestSlot = i; }
        }
        if (bestSlot != -1) mc.player.getInventory().selectedSlot = bestSlot;
    }
}
