package com.regin.client.module.render;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import java.awt.Color;

public class OreSim extends Module {
    private final Setting<Integer> radius = register(new Setting<>("Radius", 5, 1, 16));

    public OreSim() { super("OreSim", "Highlights ores through terrain", Category.RENDER); }

    @EventListener
    public void onRender(RenderEvent e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        BlockPos center = mc.player.getBlockPos();
        int r = radius.getValue();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = center.add(x, y, z);
                    Color col = getOreColor(mc.world.getBlockState(pos).getBlock());
                    if (col != null) drawBox(e.matrixStack, pos, col);
                }
    }

    private Color getOreColor(Block b) {
        String id = net.minecraft.registry.Registries.BLOCK.getId(b).getPath();
        if (id.contains("diamond"))  return new Color(0x00FFFF);
        if (id.contains("emerald"))  return new Color(0x00FF00);
        if (id.contains("ancient"))  return new Color(0xCC6600);
        if (id.contains("gold"))     return new Color(0xFFD700);
        if (id.contains("iron"))     return new Color(0xAAAAAA);
        if (id.contains("redstone")) return new Color(0xFF0000);
        if (id.contains("lapis"))    return new Color(0x0000FF);
        if (id.contains("coal"))     return new Color(0x333333);
        if (id.contains("copper"))   return new Color(0xFF8C00);
        return null;
    }

    private void drawBox(MatrixStack ms, BlockPos pos, Color color) {
        // Delegate to RenderUtils.drawBox(ms, Box.enclosing(pos, pos.add(1,1,1)), color)
    }
}
