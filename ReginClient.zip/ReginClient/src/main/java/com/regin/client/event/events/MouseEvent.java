package com.regin.client.event.events;

import com.regin.client.event.Event;

public class MouseEvent extends Event {
    public final double x, y;
    public final int    button, action;

    public MouseEvent(double x, double y, int button, int action) {
        this.x      = x;
        this.y      = y;
        this.button = button;
        this.action = action;
    }
}
