package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class KeyWindCharge extends Module {
    public KeyWindCharge() { super("KeyWindCharge", "Throws wind charge on keybind press", Category.MISC); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.WIND_CHARGE) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = prev;
                break;
            }
        }
        setEnabled(false);
    }
}
