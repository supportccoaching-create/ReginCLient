package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoDoubleHand extends Module {
    private final Setting<Boolean> crystal = register(new Setting<>("Crystal", true));
    private final Setting<Boolean> totem   = register(new Setting<>("Totem",   false));

    public AutoDoubleHand() {
        super("AutoDoubleHand", "Manages mainhand/offhand swap for crystal+totem simultaneously", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        var offhand = mc.player.getOffHandStack();
        if (totem.getValue() && offhand.getItem() != Items.TOTEM_OF_UNDYING)
            swapToOffhand(mc, Items.TOTEM_OF_UNDYING);
        else if (crystal.getValue() && offhand.getItem() != Items.END_CRYSTAL)
            swapToOffhand(mc, Items.END_CRYSTAL);
    }

    private void swapToOffhand(MinecraftClient mc, net.minecraft.item.Item item) {
        for (int i = 0; i < mc.player.playerScreenHandler.slots.size(); i++) {
            if (mc.player.playerScreenHandler.slots.get(i).getStack().getItem() != item) continue;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 45, 0, SlotActionType.PICKUP, mc.player);
            if (!mc.player.currentScreenHandler.getCursorStack().isEmpty())
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, 0, SlotActionType.PICKUP, mc.player);
            return;
        }
    }
}
