package com.regin.client.mixin;

import com.regin.client.core.Client;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.message.MessageSignatureData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void onSendChat(String message, MessageSignatureData sig, CallbackInfo ci) {
        if (Client.INSTANCE.commandManager == null) return;
        if (Client.INSTANCE.commandManager.handleInput(message)) ci.cancel();
    }
}
