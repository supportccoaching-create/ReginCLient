package com.regin.client.command;

import com.regin.client.core.Client;
import com.regin.client.module.Module;

import java.util.*;

public class CommandManager {

    private final Map<String, Command> commands = new LinkedHashMap<>();
    private String prefix = ".";

    public void registerAll() {
        register(new BindCommand());
        register(new ToggleCommand());
        register(new ConfigCommand());
        register(new HelpCommand(this));
    }

    public void register(Command cmd) {
        commands.put(cmd.getName().toLowerCase(), cmd);
    }

    public boolean handleInput(String raw) {
        if (!raw.startsWith(prefix)) return false;

        String[] parts = raw.substring(prefix.length()).trim().split("\\s+");
        if (parts.length == 0 || parts[0].isEmpty()) return false;

        Command cmd = commands.get(parts[0].toLowerCase());
        if (cmd == null) {
            chat("§cUnknown command: " + parts[0]);
            return true;
        }

        String[] args = Arrays.copyOfRange(parts, 1, parts.length);
        cmd.execute(args);
        return true;
    }

    public static void chat(String msg) {
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(net.minecraft.text.Text.literal("§5[Regin] §r" + msg), false);
        }
    }

    public String getPrefix() { return prefix; }
    public void   setPrefix(String p) { this.prefix = p; }
    public Collection<Command> getCommands() { return commands.values(); }
}

// ── Command base ──────────────────────────────────────────────────────────────
abstract class Command {
    private final String name;
    private final String usage;
    Command(String name, String usage) { this.name = name; this.usage = usage; }
    public String getName()  { return name; }
    public String getUsage() { return usage; }
    public abstract void execute(String[] args);
}

// ── .bind <module> <key> ──────────────────────────────────────────────────────
class BindCommand extends Command {
    BindCommand() { super("bind", ".bind <module> <key>"); }

    @Override
    public void execute(String[] args) {
        if (args.length < 2) { CommandManager.chat("Usage: " + getUsage()); return; }
        Module m = Client.INSTANCE.moduleManager.get(args[0]);
        if (m == null) { CommandManager.chat("Module not found: " + args[0]); return; }

        try {
            int key = org.lwjgl.glfw.GLFW.class
                .getField("GLFW_KEY_" + args[1].toUpperCase())
                .getInt(null);
            m.setKey(key);
            CommandManager.chat("Bound §d" + m.getName() + " §rto §d" + args[1].toUpperCase());
        } catch (Exception e) {
            CommandManager.chat("Invalid key: " + args[1]);
        }
    }
}

// ── .toggle <module> ──────────────────────────────────────────────────────────
class ToggleCommand extends Command {
    ToggleCommand() { super("toggle", ".toggle <module>"); }

    @Override
    public void execute(String[] args) {
        if (args.length < 1) { CommandManager.chat("Usage: " + getUsage()); return; }
        Module m = Client.INSTANCE.moduleManager.get(args[0]);
        if (m == null) { CommandManager.chat("Module not found: " + args[0]); return; }
        m.toggle();
        CommandManager.chat("§d" + m.getName() + " §r-> " + (m.isEnabled() ? "§aON" : "§cOFF"));
    }
}

// ── .config <save|load> ───────────────────────────────────────────────────────
class ConfigCommand extends Command {
    ConfigCommand() { super("config", ".config <save|load>"); }

    @Override
    public void execute(String[] args) {
        if (args.length < 1) { CommandManager.chat("Usage: " + getUsage()); return; }
        switch (args[0].toLowerCase()) {
            case "save" -> { Client.INSTANCE.configManager.save(); CommandManager.chat("Config saved."); }
            case "load" -> { Client.INSTANCE.configManager.load(); CommandManager.chat("Config loaded."); }
            default     ->   CommandManager.chat("Usage: " + getUsage());
        }
    }
}

// ── .help ─────────────────────────────────────────────────────────────────────
class HelpCommand extends Command {
    private final CommandManager manager;
    HelpCommand(CommandManager m) { super("help", ".help"); this.manager = m; }

    @Override
    public void execute(String[] args) {
        CommandManager.chat("§dAvailable commands:");
        for (Command cmd : manager.getCommands()) {
            CommandManager.chat("  §5" + cmd.getUsage());
        }
    }
}
