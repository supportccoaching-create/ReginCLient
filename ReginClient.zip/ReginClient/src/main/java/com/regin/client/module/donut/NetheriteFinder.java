package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class NetheriteFinder extends Module {
    private final Setting<Integer> radius = register(new Setting<>("Radius", 8, 1, 16));

    public NetheriteFinder() {
        super("NetheriteFinder", "Highlights ancient debris in surrounding terrain", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        BlockPos center = mc.player.getBlockPos();
        int r = radius.getValue();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    BlockPos pos = center.add(x, y, z);
                    if (mc.world.getBlockState(pos).getBlock()
                            == net.minecraft.block.Blocks.ANCIENT_DEBRIS) {
                        mc.player.sendMessage(
                            net.minecraft.text.Text.literal(
                                "§5[Netherite] §d" + pos.toShortString()), true);
                    }
                }
            }
        }
    }
}

// ── RtpBaseFinder ─────────────────────────────────────────────────────────────
