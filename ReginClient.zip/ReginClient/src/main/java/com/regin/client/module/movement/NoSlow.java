package com.regin.client.module.movement;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class NoSlow extends Module {
    public NoSlow() { super("NoSlow", "Prevents slowdown from using items, webs, etc.", Category.MOVEMENT); }
    // Mixin: cancels velocity reduction in Entity#slowMovement
}
