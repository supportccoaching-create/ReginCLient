package com.regin.client.module.render;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class HUD extends Module {
    public HUD() { super("HUD", "Renders client info overlay (module list, coords, FPS)", Category.RENDER); }
    // On/off toggle only — rendering handled by HUDRenderer injected via InGameHudMixin
}
