package com.regin.client.mixin;

import com.regin.client.core.Client;
import com.regin.client.gui.hud.HUDRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    private static final HUDRenderer HUD_RENDERER = new HUDRenderer();

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext ctx, float delta, CallbackInfo ci) {
        if (Client.INSTANCE.eventBus == null) return;
        HUD_RENDERER.render(ctx, delta);
    }
}
