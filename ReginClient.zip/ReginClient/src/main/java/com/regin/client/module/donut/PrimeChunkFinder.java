package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class PrimeChunkFinder extends Module {
    public PrimeChunkFinder() {
        super("PrimeChunkFinder", "Highlights chunks whose X and Z coordinates are both prime", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        ChunkPos cur = new ChunkPos(mc.player.getBlockPos());
        for (int cx = cur.x - 8; cx <= cur.x + 8; cx++) {
            for (int cz = cur.z - 8; cz <= cur.z + 8; cz++) {
                if (isPrime(Math.abs(cx)) && isPrime(Math.abs(cz))) {
                    // render chunk border — handled in RenderEvent
                }
            }
        }
    }

    private boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; (long) i * i <= n; i++)
            if (n % i == 0) return false;
        return true;
    }
}
