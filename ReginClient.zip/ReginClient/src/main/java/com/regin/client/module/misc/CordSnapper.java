package com.regin.client.module.misc;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CordSnapper extends Module {
    // hookOwner UUID -> hook entity ID
    private final Map<UUID, Integer> hookOwners = new HashMap<>();

    public CordSnapper() { super("CordSnapper", "Tracks fishing hooks to detect players behind cover", Category.MISC); }

    @EventListener
    public void onPacket(PacketEvent e) {
        if (e.direction != PacketEvent.Direction.RECEIVE) return;
        if (!(e.packet instanceof EntitySpawnS2CPacket pkt)) return;
        if (pkt.getEntityType() != net.minecraft.entity.EntityType.FISHING_BOBBER) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        UUID ownerUUID = pkt.getUuid();
        hookOwners.put(ownerUUID, pkt.getId());

        mc.player.sendMessage(
            net.minecraft.text.Text.literal("§5[CordSnapper] §dFishing hook from " + ownerUUID), false);
    }

    @Override public void onDisable() { hookOwners.clear(); }
}
