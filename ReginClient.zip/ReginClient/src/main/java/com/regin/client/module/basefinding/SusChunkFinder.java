package com.regin.client.module.basefinding;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.RenderEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import java.awt.Color;
import java.util.*;

public class SusChunkFinder extends Module {
    // Tracks block change counts per chunk per session
    private final java.util.Map<ChunkPos, Integer> changeMap = new java.util.HashMap<>();

    private final Setting<Integer> threshold = register(new Setting<>("Threshold", 5, 1, 50));

    public SusChunkFinder() {
        super("SusChunkFinder", "Flags chunks with unusual block change activity", Category.BASEFINDING);
    }

    // Listens to BlockUpdateS2CPacket, increments counter per chunk
    // When counter > threshold: flag as suspicious
    public void registerBlockChange(BlockPos pos) {
        ChunkPos cp = new ChunkPos(pos);
        int count = changeMap.getOrDefault(cp, 0) + 1;
        changeMap.put(cp, count);

        if (count >= threshold.getValue()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                mc.player.sendMessage(
                    net.minecraft.text.Text.literal(
                        "[SusChunk] Activity at chunk " + cp.x + "," + cp.z
                        + " (" + count + " changes)"
                    ), false
                );
            }
        }
    }
}

// ── SuspiciousESP ─────────────────────────────────────────────────────────────
