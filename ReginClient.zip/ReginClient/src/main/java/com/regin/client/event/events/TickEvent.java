package com.regin.client.event.events;

import com.regin.client.event.Event;

public class TickEvent extends Event {
    public enum Phase { PRE, POST }
    public final Phase phase;

    public TickEvent(Phase phase) { this.phase = phase; }
}
