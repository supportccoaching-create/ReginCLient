package com.regin.client.module.player;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoArmor extends Module {
    public AutoArmor() { super("AutoArmor", "Automatically equips best armor from inventory", Category.PLAYER); }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int[] armorGuiSlots = {5, 6, 7, 8};
        for (int armorSlot : armorGuiSlots) {
            ItemStack current = mc.player.playerScreenHandler.slots.get(armorSlot).getStack();
            int bestSlot = findBetter(mc, armorSlot, current);
            if (bestSlot == -1) continue;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, bestSlot, 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, armorSlot, 0, SlotActionType.PICKUP, mc.player);
            if (!mc.player.currentScreenHandler.getCursorStack().isEmpty())
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, bestSlot, 0, SlotActionType.PICKUP, mc.player);
        }
    }

    private int findBetter(MinecraftClient mc, int guiSlot, ItemStack current) {
        int curProt = getProtection(current);
        int best = -1, bestProt = curProt;
        for (int i = 9; i < 45; i++) {
            ItemStack s = mc.player.playerScreenHandler.slots.get(i).getStack();
            if (!(s.getItem() instanceof ArmorItem ai)) continue;
            if (!isForSlot(ai, guiSlot)) continue;
            int prot = getProtection(s);
            if (prot > bestProt) { bestProt = prot; best = i; }
        }
        return best;
    }

    private int getProtection(ItemStack s) {
        return s.isEmpty() || !(s.getItem() instanceof ArmorItem ai) ? 0 : ai.getProtection();
    }

    private boolean isForSlot(ArmorItem ai, int guiSlot) {
        return switch (guiSlot) {
            case 5 -> ai.getSlotType() == EquipmentSlot.HEAD;
            case 6 -> ai.getSlotType() == EquipmentSlot.CHEST;
            case 7 -> ai.getSlotType() == EquipmentSlot.LEGS;
            case 8 -> ai.getSlotType() == EquipmentSlot.FEET;
            default -> false;
        };
    }
}
