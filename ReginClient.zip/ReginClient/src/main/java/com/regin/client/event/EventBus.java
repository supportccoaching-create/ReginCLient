package com.regin.client.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {

    // listener entry: target object + method to invoke
    private static class ListenerEntry implements Comparable<ListenerEntry> {
        final Object object;
        final Method method;
        final byte   priority;

        ListenerEntry(Object object, Method method, byte priority) {
            this.object   = object;
            this.method   = method;
            this.priority = priority;
            this.method.setAccessible(true);
        }

        @Override
        public int compareTo(ListenerEntry o) {
            return Byte.compare(o.priority, this.priority); // higher priority first
        }
    }

    // eventClass -> sorted list of listeners
    private final Map<Class<?>, CopyOnWriteArrayList<ListenerEntry>> listeners =
            new ConcurrentHashMap<>();

    public void subscribe(Object object) {
        for (Method m : object.getClass().getDeclaredMethods()) {
            EventListener ann = m.getAnnotation(EventListener.class);
            if (ann == null) continue;
            if (m.getParameterCount() != 1) continue;

            Class<?> eventType = m.getParameterTypes()[0];
            listeners.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>())
                     .add(new ListenerEntry(object, m, ann.priority()));

            // keep sorted by priority after each insert
            listeners.get(eventType).sort(null);
        }
    }

    public void unsubscribe(Object object) {
        for (CopyOnWriteArrayList<ListenerEntry> list : listeners.values()) {
            list.removeIf(e -> e.object == object);
        }
    }

    public void post(Event event) {
        List<ListenerEntry> list = listeners.get(event.getClass());
        if (list == null || list.isEmpty()) return;

        for (ListenerEntry entry : list) {
            if (event.isCancelled()) break;
            try {
                entry.method.invoke(entry.object, event);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
