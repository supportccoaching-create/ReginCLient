package com.regin.client.module.render;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class TargetHUD extends Module {
    public TargetHUD() { super("TargetHUD", "Renders target info panel (name, HP, distance)", Category.RENDER); }
    // Rendered inside HUDRenderer#renderTargetHUD when enabled
}
