package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {

    private final Setting<Boolean> strict = register(new Setting<>("Strict", true));

    public AutoTotem() {
        super("AutoTotem", "Keeps totem of undying in offhand", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;

        ClientPlayerEntity player = mc.player;
        ItemStack offhand = player.getOffHandStack();

        if (offhand.getItem() == Items.TOTEM_OF_UNDYING) return;

        // find totem in hotbar or inventory
        int totemSlot = findTotem(player);
        if (totemSlot == -1) return;

        // pick up totem to cursor, place in offhand (slot 45)
        mc.interactionManager.clickSlot(
            player.playerScreenHandler.syncId,
            totemSlot, 0,
            SlotActionType.PICKUP,
            player
        );
        mc.interactionManager.clickSlot(
            player.playerScreenHandler.syncId,
            45, 0,
            SlotActionType.PICKUP,
            player
        );
        // if cursor still has it, put back
        if (!mc.player.currentScreenHandler.getCursorStack().isEmpty()) {
            mc.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                totemSlot, 0,
                SlotActionType.PICKUP,
                player
            );
        }
    }

    private int findTotem(ClientPlayerEntity player) {
        // search inventory slots 0..44 (9 hotbar + 27 main + 9 armor/offhand area)
        for (int i = 0; i < player.playerScreenHandler.slots.size(); i++) {
            ItemStack stack = player.playerScreenHandler.slots.get(i).getStack();
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        return -1;
    }
}
