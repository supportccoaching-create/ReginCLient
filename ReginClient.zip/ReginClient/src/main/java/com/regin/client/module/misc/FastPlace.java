package com.regin.client.module.misc;

import com.regin.client.module.Category;
import com.regin.client.module.Module;

public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", "Removes block placement delay", Category.MISC); }
    // Mixin on MinecraftClient: set rightClickDelay = 0 every tick when enabled
}
