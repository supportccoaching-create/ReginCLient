package com.regin.client;

import com.regin.client.core.Client;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReginClient implements ModInitializer {

    public static final String NAME    = "ReginClient";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER  = LoggerFactory.getLogger(NAME);

    @Override
    public void onInitialize() {
        LOGGER.info("[{}] Starting v{}", NAME, VERSION);
        Client.INSTANCE.init();
        LOGGER.info("[{}] Ready.", NAME);
    }
}
