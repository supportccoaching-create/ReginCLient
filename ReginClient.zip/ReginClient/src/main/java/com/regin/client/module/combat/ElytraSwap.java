package com.regin.client.module.combat;

import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class ElytraSwap extends Module {
    public ElytraSwap() {
        super("ElytraSwap", "Instantly swaps between elytra and chestplate", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int chestSlot = 6;
        for (int i = 0; i < mc.player.playerScreenHandler.slots.size(); i++) {
            var item = mc.player.playerScreenHandler.slots.get(i).getStack().getItem();
            if (item == Items.ELYTRA || item instanceof ArmorItem) {
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, chestSlot, 0, SlotActionType.PICKUP, mc.player);
                if (!mc.player.currentScreenHandler.getCursorStack().isEmpty())
                    mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, 0, SlotActionType.PICKUP, mc.player);
                break;
            }
        }
        setEnabled(false);
    }
}
