package com.regin.client.module.donut;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.PacketEvent;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import com.regin.client.setting.Setting;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

public class RtpBaseFinder extends Module {
    public RtpBaseFinder() {
        super("RtpBaseFinder", "Scans loaded chunks for player-placed storage blocks", Category.DONUT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        mc.world.blockEntities.forEach(be -> {
            if (!(be instanceof ChestBlockEntity)
             && !(be instanceof FurnaceBlockEntity)
             && !(be instanceof ShulkerBoxBlockEntity)) return;

            BlockPos pos  = be.getPos();
            double   dist = mc.player.getPos()
                .distanceTo(net.minecraft.util.math.Vec3d.of(pos));
            if (dist < 256) {
                mc.player.sendMessage(
                    net.minecraft.text.Text.literal(
                        "§5[RtpFinder] §dPossible base: " + pos.toShortString()), false);
            }
        });
    }
}

// ── AutoShulkerBuy ────────────────────────────────────────────────────────────
