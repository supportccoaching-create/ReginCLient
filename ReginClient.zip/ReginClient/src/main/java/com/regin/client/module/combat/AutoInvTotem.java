package com.regin.client.module.combat;

import com.regin.client.event.EventListener;
import com.regin.client.event.events.TickEvent;
import com.regin.client.module.Category;
import com.regin.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;

public class AutoInvTotem extends Module {
    public AutoInvTotem() {
        super("AutoInvTotem", "Pulls totem from shulkers when inventory has none", Category.COMBAT);
    }

    @EventListener
    public void onTick(TickEvent e) {
        if (e.phase != TickEvent.Phase.PRE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        for (int i = 0; i < mc.player.playerScreenHandler.slots.size(); i++) {
            if (mc.player.playerScreenHandler.slots.get(i).getStack().getItem()
                    == Items.TOTEM_OF_UNDYING) return;
        }
        // No totems found — trigger shulker open logic (server-specific packet flow)
    }
}
